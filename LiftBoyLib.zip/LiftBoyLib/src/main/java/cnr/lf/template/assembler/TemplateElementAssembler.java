/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnr.lf.template.assembler;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.lf.cnr.util.Logs;
import com.lf.cnr.util.SetList;
import it.cnr.irea.ediT.model.PreTemplateElement;
import it.cnr.irea.ediT.model.PreTemplateItem;
import it.cnr.irea.ediT.model.TemplateElement;
import it.cnr.irea.ediT.model.TemplateItem;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author Luca Frigerio
 */
public class TemplateElementAssembler {

    public static final String MULTIPLEINDICATOR = "XritX";
    public static final String SEPARATOR = "_";
    public static final String TAG = "TemplateElementAssembler";

    public static List<TemplateElement> fromPreTemplateElementToTemplateElement(PreTemplateElement t) throws Exception {

//        List<PosizioneEValore> elenco_multiply = Lists.newArrayList();
        TemplateElement first = new TemplateElement(t.getId());
        first.setLabel(t.getLabel());
        first.setMandatory(t.getMandatory());
        first.setRoot(t.getRoot());
        first.setRepresents_element(t.getId());

        List<TemplateElement> exit = Lists.newArrayList();

//        Where the key is the value in the iso; L'altro è l'enco dei templateElement id e il nome da mettere .
        Map<TemplateElement, Integer> mappa = Maps.newHashMap();
        SetList<TemplateItem> setTI = new SetList<>();

        exit.add(first);

        int contatore = 0;

        for (TemplateItem z : t.getItems()) {
            if (t.getId().equals("keyw_voc_contr")) {
                Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Logs.application(TAG, t.getId() + " - " + contatore);
                contatore++;
                Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            } else {
                Logs.application(TAG, "-------------------------------------------------------------------------------------------------------");
                Logs.application(TAG, t.getId());
                Logs.application(TAG, "-------------------------------------------------------------------------------------------------------");
            }
            PreTemplateItem pti = (PreTemplateItem) z;

            int counter_of_names = 0;
            int counter_elements = 0;
            if (pti.sizeOfMultipleValues() == 0) {
                TemplateItem i = new TemplateItem(pti.getId());
               

                i.setDatatype(pti.getDatatype());
                i.setDatasource(pti.getDatasource());
//                Logs.application("ASSEMBLER", "pti.getElement_Id()--> :" + pti.getElement_Id());
//                            i.setElement_Id(exit.get(counter_of_names).getId());
                i.setFixed(pti.getFixed());
                i.setHasIndex(pti.getHasIndex());
                // errori di cristiano
                i.setLanguageNeutral(pti.getLanguageNeutral());
                i.setLabelValue(pti.getLabelValue());

                //-------------------------------------------------------
                i.setIsLanguageNeutral(pti.getIsLanguageNeutral());
                i.setLanguageNeutral(pti.getLanguageNeutral());
                i.setOutIndex(pti.getOutIndex());
                i.setPath(pti.getPath());
                i.setUrnValue(pti.getUrnValue());
                i.setUseCode(pti.getUseCode());
                i.setValue(pti.getValue());
                setTI.add(i);
                Logs.application(TAG, "-------------------------------------------------------------------------------------------------------");
                Logs.application(TAG, "--NON HA RISULTATI");
                Logs.application(TAG, "-------------------------------------------------------------------------------------------------------");
                Logs.application(TAG, i.toString());
                Logs.application(TAG, "-------------------------------------------------------------------------------------------------------");
            } else {
                for (int a = 0; a < pti.sizeOfMultipleValues(); a++) {

                    Logs.application(TAG, "--------------------------------");
                    Logs.application(TAG, "[[ "+ pti.getId() + " ]] Value in the iso n° " + a);
                    Logs.application(TAG, "--------------------------------");

                    TemplateItem i;
                    String elementName = "";

                    if (a > 0) {
                        //  IF IT IS NOT THE ONLY VALUES IT REQUIRES XRITX
                        counter_of_names++;
                        counter_elements++;

                        // COSA DIAVOLO FA ? PERCHE' ?
                        if (exit.size() < (counter_of_names + 1)) {

                            for (int f = 0; f < counter_of_names; f++) {
                                elementName = elementName + SEPARATOR + MULTIPLEINDICATOR;
                            }

                            TemplateElement element = new TemplateElement(t.getId() + elementName);
                            element.setLabel(t.getLabel());
                            element.setMandatory(t.getMandatory());
                            element.setRoot(t.getRoot());
                            element.setRepresents_element(t.getId());
                            exit.add(element);

                        }
                    }
                    int limit = 1;
                    String value_of_counter = null;
                    String temp_multiple_value = pti.getMultiple_values().get(counter_elements);
                    Logs.application(TAG, "pti.isToSearch() : " + pti.isToSearch());
                    
                    if (pti.isToSearch()) {
                        
                        Logs.application(TAG, "- pti.hasMultipleValuesForTheQueries(pti.getMultiple_to_search().get(counter_elements)) : " + pti.hasMultipleValuesForTheQueries(pti.getMultiple_to_search().get(counter_elements)));
                        if (pti.hasMultipleValuesForTheQueries(pti.getMultiple_to_search().get(counter_elements))) {
                            limit = pti.sizeOfMultipleValue(pti.getMultiple_to_search().get(counter_elements));
                            value_of_counter = pti.getMultiple_to_search().get(counter_elements);
                        }

                    }
                    
                    for (int x = 0; x < limit; x++) {

                        Logs.application(TAG, "--------------------");
                        Logs.application(TAG, "Value in the query n° " + x + " | " + a);
                        Logs.application(TAG, "--------------------");
                        String elementName2 = "";

                        if (x > 0) {
                            // creo un altro elemet
                            counter_of_names++;
                            for (int f = 0; f < counter_of_names; f++) {
                                elementName2 = elementName2 + SEPARATOR + MULTIPLEINDICATOR;
                            }

                            TemplateElement element = new TemplateElement(t.getId() + elementName2);
                            element.setLabel(t.getLabel());
                            element.setMandatory(t.getMandatory());
                            element.setRoot(t.getRoot());
                            element.setRepresents_element(t.getId());
                            exit.add(element);

                        }

                        int count = StringUtils.countMatches(exit.get(counter_of_names).getId(), MULTIPLEINDICATOR);
                        String name = getName(pti.getId(), count);

                        if (pti.isToSearch()) {
                            if (pti.hasMultipleValuesForTheQueries(value_of_counter)) {
                                i = new TemplateItem(name);
                                Logs.application(TAG, "IT IS TO SEARCH!!!!!");
                                i.setCodeValue(pti.getMultiple_codevalue().get(value_of_counter).get(x));
                                i.setDatatype(pti.getDatatype());
                                i.setDatasource(pti.getDatasource());
//                Logs.application("ASSEMBLER", "pti.getElement_Id()--> :" + pti.getElement_Id());
                                i.setElement_Id(exit.get(counter_of_names).getId());
                                i.setFixed(pti.getFixed());
                                i.setHasIndex(pti.getHasIndex());
                                // errori di cristiano
                                i.setLanguageNeutral(pti.getLanguageNeutral());
                                i.setLabelValue(temp_multiple_value);

                                //-------------------------------------------------------
                                i.setIsLanguageNeutral(pti.getIsLanguageNeutral());
                                i.setLanguageNeutral(pti.getLanguageNeutral());
                                i.setOutIndex(pti.getOutIndex());
                                i.setPath(pti.getPath());
                                i.setUrnValue(pti.getUrnValue());
                                i.setUseCode(pti.getUseCode());
                                i.setValue(temp_multiple_value);

                                exit.get(counter_of_names).addItem(i);

                            } else {
                                i = new TemplateItem(name);
                                Logs.application(TAG, "IT IS TO SEARCH!!!!!");
                                // BECAUSE NO VALUE!!!!
//                                i.setCodeValue(pti.getMultiple_codevalue().get(value_of_counter).get(x));
                                i.setDatatype(pti.getDatatype());
                                i.setDatasource(pti.getDatasource());
//                Logs.application("ASSEMBLER", "pti.getElement_Id()--> :" + pti.getElement_Id());
                                i.setElement_Id(exit.get(counter_of_names).getId());
                                i.setFixed(pti.getFixed());
                                i.setHasIndex(pti.getHasIndex());
                                // errori di cristiano
                                i.setLanguageNeutral(pti.getLanguageNeutral());
                                i.setLabelValue(temp_multiple_value);

                                //-------------------------------------------------------
                                i.setIsLanguageNeutral(pti.getIsLanguageNeutral());
                                i.setLanguageNeutral(pti.getLanguageNeutral());
                                i.setOutIndex(pti.getOutIndex());
                                i.setPath(pti.getPath());
                                i.setUrnValue(pti.getUrnValue());
                                i.setUseCode(pti.getUseCode());
                                i.setValue(temp_multiple_value);

                                exit.get(counter_of_names).addItem(i);

                            }
                        } else {
                            i = new TemplateItem(pti.getId());
                            Logs.application(TAG, "IT IS NOT TO SEARCH!!!!!");

                            i.setDatatype(pti.getDatatype());
                            i.setDatasource(pti.getDatasource());
//                Logs.application("ASSEMBLER", "pti.getElement_Id()--> :" + pti.getElement_Id());
//                            i.setElement_Id(exit.get(counter_of_names).getId());
                            i.setFixed(pti.getFixed());
                            i.setHasIndex(pti.getHasIndex());
                            // errori di cristiano
                            i.setLanguageNeutral(pti.getLanguageNeutral());
                            i.setLabelValue(temp_multiple_value);

                            //-------------------------------------------------------
                            i.setIsLanguageNeutral(pti.getIsLanguageNeutral());
                            i.setLanguageNeutral(pti.getLanguageNeutral());
                            i.setOutIndex(pti.getOutIndex());
                            i.setPath(pti.getPath());
                            i.setUrnValue(pti.getUrnValue());
                            i.setUseCode(pti.getUseCode());
                            i.setValue(temp_multiple_value);
                            setTI.add(i);

                        }
                    }
//                    Logs.application(TAG, "counter_of_names  " + counter_of_names + " | " + exit.get(counter_of_names).getItems().size());
                }

            }
        }

        for (TemplateElement te : exit) {

            Logs.application(TAG, "----->" + te.getId());
            for (TemplateItem pti : setTI) {

                TemplateItem i = new TemplateItem(getName(pti.getId(), StringUtils.countMatches(te.getId(), MULTIPLEINDICATOR)));
                Logs.application(TAG, "---------->" + i.getId());
                Logs.application(TAG, "---------->" + StringUtils.countMatches(te.getId(), MULTIPLEINDICATOR));
                Logs.application(TAG, "----------------------------------------------------------");

                i.setDatatype(pti.getDatatype());
                i.setDatasource(pti.getDatasource());
//                Logs.application("ASSEMBLER", "pti.getElement_Id()--> :" + pti.getElement_Id());
                i.setElement_Id(te.getId());
                i.setFixed(pti.getFixed());
                i.setHasIndex(pti.getHasIndex());
                // errori di cristiano
                i.setLanguageNeutral(pti.getLanguageNeutral());
                i.setLabelValue(pti.getLabelValue());

                //-------------------------------------------------------
                i.setIsLanguageNeutral(pti.getIsLanguageNeutral());
                i.setLanguageNeutral(pti.getLanguageNeutral());
                i.setOutIndex(pti.getOutIndex());
                i.setPath(pti.getPath());
                i.setUrnValue(pti.getUrnValue());
                i.setUseCode(pti.getUseCode());
                i.setValue(pti.getValue());

                te.addItem(i);
            }
        }

        return exit;
//        return 
    }

    private static String getName(String name, int count) {

        if (name.contains(SEPARATOR)) {
            String[] nameSplitted = name.split(SEPARATOR);

            List<String> lista = Arrays.stream(nameSplitted).collect(Collectors.toList());

            String last = lista.get(lista.size() - 1);
            lista.remove(lista.size() - 1);
            for (int g = 0; g < count; g++) {
                lista.add(MULTIPLEINDICATOR);
            }
            name = "";
            boolean isFirst = true;
            for (String ee : lista) {
                if (isFirst) {
                    name = ee;
                    isFirst = false;
                } else {
                    name = name + SEPARATOR + ee;
                }

            }
            name = name + SEPARATOR + last;
        }
        return name;
    }

}
