/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnr.lf.template.classes;

import com.google.common.collect.ImmutableList;
import java.util.List;

/**
 *
 * @author Luca Frigerio
 */
public class Element {

    private ImmutableList<Help> help;

    private String isMultiple;

    private String hasRoot;

    private String isMandatory;

    private Produces produces;

    private ImmutableList<Label> label;
    

    public List<Help> getHelp() {
        return help;
    }

    public String getIsMultiple() {
        return isMultiple;
    }

    public void setIsMultiple(String isMultiple) {
        this.isMultiple = isMultiple;
    }

    public String getHasRoot() {
        return hasRoot;
    }

    public void setHasRoot(String hasRoot) {
        this.hasRoot = hasRoot;
    }

    public String getIsMandatory() {
        return isMandatory;
    }

    public void setIsMandatory(String isMandatory) {
        this.isMandatory = isMandatory;
    }

    public Produces getProduces() {
        return produces;
    }

    public void setProduces(Produces produces) {
        this.produces = produces;
    }

    public List<Label> getLabel() {
        return label;
    }

     
}
