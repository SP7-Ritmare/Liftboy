/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnr.lf.template.classes;

/**
 *
 * @author Luca Frigerio
 */
public class Item
{
    private String isFixed;

    private Label[] label;

    private String outIndex;

    private String hasPath;

    private String hasDatatype;

    private String hasIndex;

    private String datasource;

    public String getIsFixed ()
    {
        return isFixed;
    }

    public void setIsFixed (String isFixed)
    {
        this.isFixed = isFixed;
    }

    public Label[] getLabel ()
    {
        return label;
    }

    public void setLabel (Label[] label)
    {
        this.label = label;
    }

    public String getOutIndex ()
    {
        return outIndex;
    }

    public void setOutIndex (String outIndex)
    {
        this.outIndex = outIndex;
    }

    public String getHasPath ()
    {
        return hasPath;
    }

    public void setHasPath (String hasPath)
    {
        this.hasPath = hasPath;
    }

    public String getHasDatatype ()
    {
        return hasDatatype;
    }

    public void setHasDatatype (String hasDatatype)
    {
        this.hasDatatype = hasDatatype;
    }

    public String getHasIndex ()
    {
        return hasIndex;
    }

    public void setHasIndex (String hasIndex)
    {
        this.hasIndex = hasIndex;
    }

    public String getDatasource ()
    {
        return datasource;
    }

    public void setDatasource (String datasource)
    {
        this.datasource = datasource;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [isFixed = "+isFixed+", label = "+label+", outIndex = "+outIndex+", hasPath = "+hasPath+", hasDatatype = "+hasDatatype+", hasIndex = "+hasIndex+", datasource = "+datasource+"]";
    }
}