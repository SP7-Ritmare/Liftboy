/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnr.lf.template.classes;

import java.util.Objects;

/**
 *
 * @author Luca Frigerio
 */
public class Preamble {
    
    private final String version,template,fileId,fileUri;

    public Preamble(String version, String template, String fileId, String fileUri) {
        this.version = version;
        this.template = template;
        this.fileId = fileId;
        this.fileUri = fileUri;
    }

    public String getVersion() {
        return version;
    }

    public String getTemplate() {
        return template;
    }

    public String getFileId() {
        return fileId;
    }

    public String getFileUri() {
        return fileUri;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.version);
        hash = 37 * hash + Objects.hashCode(this.template);
        hash = 37 * hash + Objects.hashCode(this.fileId);
        hash = 37 * hash + Objects.hashCode(this.fileUri);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Preamble other = (Preamble) obj;
        if (!Objects.equals(this.version, other.version)) {
            return false;
        }
        if (!Objects.equals(this.template, other.template)) {
            return false;
        }
        if (!Objects.equals(this.fileId, other.fileId)) {
            return false;
        }
        if (!Objects.equals(this.fileUri, other.fileUri)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Preamble{" + "version=" + version + ", template=" + template + ", fileId=" + fileId + ", fileUri=" + fileUri + '}';
    }
    
    
    
    
}
