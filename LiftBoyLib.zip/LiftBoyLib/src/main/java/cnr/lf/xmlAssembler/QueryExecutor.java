/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnr.lf.xmlAssembler;

import com.jayway.jsonpath.JsonPath;
import com.lf.cnr.util.Logs;
import it.cnr.irea.ediT.model.PreTemplateElement;
import it.cnr.irea.ediT.model.PreTemplateItem;
import it.cnr.irea.ediT.model.TemplateItem;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Luca Frigerio
 */
public class QueryExecutor {

    private String uri, currentMetadataLanguage;

    private final static String TAG = "QueryExecutor";

    private final static String PARAMOSS = "paramOss";

    private String endpoint = "http://sparql.get-it.it?query=";

//    public final String CODELISTQUERY = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> "
//            + "PREFIX dct:<http://purl.org/dc/terms/> "
//            + "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> "
//            + "PREFIX skos:<http://www.w3.org/2004/02/skos/core#> "
//            + "SELECT DISTINCT <" + uri + "> AS ?uri ?c ?l ?a ?z "
//            + "WHERE { "
//            + "	{ "
//            + "	  ?c rdf:type skos:Concept. "
//            + "	  ?c skos:inScheme <" + uri + ">. "
//            + "	  OPTIONAL { "
//            + "	      ?c skos:prefLabel ?l. "
//            + "	      FILTER ( LANG(?l) = \"en\" ) "
//            + "	  } "
//            + "	} "
//            + "	OPTIONAL { "
//            + "	    ?c skos:prefLabel ?z. "
//            + "	    FILTER ( LANG(?z) = \"zxx\" ) "
//            + "	} "
//            + "	OPTIONAL { "
//            + "	    ?c skos:prefLabel ?a. "
//            + "	    FILTER ( LANG(?a) = \"" + currentMetadataLanguage + "\" ) "
//            + "	} "
//            + "	"
//            + "} "
//            + "ORDER BY ASC(?a) ASC(?l)";
    private final PreTemplateElement templateElement;

    public QueryExecutor(final PreTemplateElement templateElement) {

        this.templateElement = templateElement;

    }

    public void doSearch() throws IOException {

        int counter = 0;
        Logs.application(TAG, "##########################################################################################################################################################################################################################################################################################################################################################################");
        Logs.application(TAG, "#  START ELEMENT ID " + this.templateElement.getId() + " #########################################################################################################################################################################################################################################################################################################################################################################");
        Logs.application(TAG, "##########################################################################################################################################################################################################################################################################################################################################################################");

        if (templateElement.getItems().isEmpty()) {
            Logs.application(TAG, "is empty");
        } else {
            Logs.application(TAG, "NUMBER OF ELEMENTS : " + templateElement.getItems().size() + " DOES IT ACCEPT MULTIPLE ? " + templateElement.isIsMultiple());
            

            for (TemplateItem ti : templateElement.getItems()) {

                PreTemplateItem pti = (PreTemplateItem) ti;
                if (pti.isToSearch()) {
                    for (int i = 0; i < pti.multiple_to_search_size(); i++) {
                        try {
                            Logs.application(TAG, "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                            Logs.application(TAG, "- ELEMENT N°" + counter + "-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                            Logs.application(TAG, "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                            Logs.application(TAG, "PTI : " + pti.toString());
                            Logs.application(TAG, "DATASOURCE : " + pti.getDatasource());

                            if (pti.getDatasource().equals(PARAMOSS)) {
                                Logs.application(TAG, "THIS DATASOURCE IS PECIAL : " + PARAMOSS);
                            }

                            Logs.application(TAG, "URL TO SEARCH : " + pti.getUrlToSearch(i));
                            String jsonResponse = httpGet(pti.getUrlToSearch(i));

                            Logs.application(TAG, "JSON RESPONSE : " + jsonResponse);
                            Logs.application(TAG, "IS CODELIST : " + pti.isCodelist());
                            Logs.application(TAG, "IS AUTOCOMPLETION : " + pti.isAutocompletion());
                            Logs.application(TAG, "I'M SEARCHING : " + pti.getUrlToSearch(i));

                            if (pti.isCodelist()) {
                                Logs.application(TAG, "QUERY OF ELEMENT N° " + counter);
                                Logs.application(TAG, pti.getCodeList().getCompleteQueryCodelist(pti.getUrlToSearch(i)));

                            }

//                            JsonLdOptions options = new JsonLdOptions();
                            try {
//                            Map<String, String> aaa = JsonPath.read(jsonResponse, "$.results.bindings[0]");

//                                String valore_risultato_query_c = JsonPath.read(jsonResponse, "$.results.bindings[0].c.value").toString();
                                // PRIMA ERA COSI'
//                                LinkedHashMap jiee = JsonPath.read(jsonResponse, "$.results.bindings[0]");
                                List<Map<String, Object>> result_list = JsonPath.read(jsonResponse, "$.results.bindings");

//                                Logs.application(TAG, "valore risultato query c : " + valore_risultato_query_c);
//                                Logs.application(TAG, "valore risultato query z : " + valore_risultato_query_z);
                                Logs.application(TAG, "NUMERO DI RISULTATI DELLA QUERY : " + result_list.size());
                                
                                
                                int count = 0;
                                if (templateElement.isIsMultiple()) {
                                    for (Map<String, Object> jiee : result_list) {
                                        Logs.application(TAG, "+" + count + "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

                                        Logs.application(TAG, "Numero di elementi : " + jiee.size());
                                        for (Object element : jiee.keySet()) {

                                            if (element.toString().equals("c")) {
                                                Logs.application(TAG, "---> : " + element.toString() + " : " + jiee.get(element).toString());
                                                // PRIMA ERA COSI'
//                                           String element_value = JsonPath.read(jsonResponse, "$.results.bindings[0]." + element.toString() + ".value").toString();
                                                String element_value = JsonPath.read(jsonResponse, "$.results.bindings[" + count + "]." + element.toString() + ".value").toString();
                                                Logs.application(TAG, "---> : " + element.toString() + " : value : " + element_value);

                                                pti.addCodeValue(pti.getMultiple_to_search().get(i), element_value);
                                            }
                                            // MODIFICA PER CRISTIANO  13/6

                                            if (element.toString().equals("b")) {
                                                Logs.application(TAG, "---> : " + element.toString() + " : " + jiee.get(element).toString());
//                                            String element_value = JsonPath.read(jsonResponse, "$.results.bindings[0]." + element.toString() + ".value").toString();
                                                String element_value = JsonPath.read(jsonResponse, "$.results.bindings[" + count + "]." + element.toString() + ".value").toString();
                                                Logs.application(TAG, "---> : " + element.toString() + " : value : " + element_value);
                                                pti.setLanguageNeutral(element_value);
                                            }

                                        }
                                        count++;
                                    }
                                } else {
                                    if (!result_list.isEmpty()) {
                                        Map<String, Object> jiee = result_list.get(0);
                                         Logs.application(TAG, "Numero di elementi : " + jiee.size());
                                        for (Object element : jiee.keySet()) {

                                            if (element.toString().equals("c")) {
//                                                Logs.application(TAG, "---> : " + element.toString() + " : " + jiee.get(element).toString());
                                                // PRIMA ERA COSI'
//                                           String element_value = JsonPath.read(jsonResponse, "$.results.bindings[0]." + element.toString() + ".value").toString();
                                                String element_value = JsonPath.read(jsonResponse, "$.results.bindings[0]." + element.toString() + ".value").toString();
                                                Logs.application(TAG, "---> : " + element.toString() + " : value : " + element_value);

                                                pti.addCodeValue(pti.getMultiple_to_search().get(i), element_value);
                                            }
                                            // MODIFICA PER CRISTIANO  13/6

                                            if (element.toString().equals("b")) {
//                                                Logs.application(TAG, "---> : " + element.toString() + " : " + jiee.get(element).toString());
//                                            String element_value = JsonPath.read(jsonResponse, "$.results.bindings[0]." + element.toString() + ".value").toString();
                                                String element_value = JsonPath.read(jsonResponse, "$.results.bindings[0]." + element.toString() + ".value").toString();
                                                Logs.application(TAG, "---> : " + element.toString() + " : value : " + element_value);
                                                pti.setLanguageNeutral(element_value);
                                            }

                                        }
                                    }
                                }
                            } catch (Exception e) {
                                Logs.application(TAG, e.getMessage());
                            }

                            Logs.application(TAG, "++++++++++++++++++++++++++++");
                            Logs.application(TAG, "PTI SIZE : " + pti.sizeOfMultipleValues());
                            Logs.application(TAG, "++++++++++++++++++++++++++++");

                        } catch (Exception e) {
                            Logs.application(TAG, "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
                            Logs.application(TAG, "Errore : " + e.getMessage());
                            Logs.application(TAG, "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
                        }
                        Logs.application(TAG, "- FINE ELEMENT " + counter + "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    }

                } else {
                    Logs.application(TAG, "ID :" + pti.getId() + " IS NOT TO SEARCH");
                    Logs.application(TAG, pti.toString());
                }
            }
        }
    }

    public String httpGet(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection conn
                = (HttpURLConnection) url.openConnection();
        conn.addRequestProperty("Accept", "application/sparql-results+json"); // Should return JSON but returns XML
        if (conn.getResponseCode() != 200) {
            return null;
        }
        BufferedReader rd = new BufferedReader(
                new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line + '\n');
        }
        rd.close();

        conn.disconnect();
        return sb.toString();
    }

}
