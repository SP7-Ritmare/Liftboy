/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnr.lf.xmlAssembler;

import cnr.lf.template.classes.Preamble;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.lf.cnr.util.Logs;
import com.lf.cnr.util.Util;
import com.lf.cnr.util.XMLUtil;
import com.ximpleware.AutoPilot;
import com.ximpleware.EOFException;
import com.ximpleware.EntityException;
import com.ximpleware.NavException;
import com.ximpleware.ParseException;
import com.ximpleware.VTDGen;
import com.ximpleware.VTDNav;
import com.ximpleware.XPathEvalException;
import com.ximpleware.XPathParseException;
import it.cnr.irea.ediT.model.CodeList;
import it.cnr.irea.ediT.model.DataType;
import it.cnr.irea.ediT.model.EndPointType;
import it.cnr.irea.ediT.model.PreTemplateElement;
import it.cnr.irea.ediT.model.PreTemplateItem;
import it.cnr.irea.ediT.model.Sparql;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/**
 *
 * @author Luca Frigerio
 */
public class VTDUtil {
    
    private final AtomicReference<String> xml_path;
    private final AtomicReference<Preamble> version;

    private final String TAG = VTDUtil.class.toString();

    private final String complete_filename_template;

    public static final String AUTOCOMPLETION = "autoCompletion";

//    private final String path = "/home/carnauser/Documenti/Temp/";
    private final Set<String> prefix;

    private final List<Sparql> sparqls;

    private final List<EndPointType> endPointTypes;

    private final String complete_filename_iso;

    private final ImmutableList<String> datatypes = Util.getNames(DataType.class);

    private final VTDNav vtdNav_template;
    private final VTDNav vtdNav_iso;

    private final AutoPilot ap_template = new AutoPilot();
    private final AutoPilot ap_iso = new AutoPilot();

    private final List<CodeList> codeLists;

//    private PreQuery getPreQueryByName(String name) {
//        
//    }
    public VTDUtil(String complete_filename_template, String complete_filename_iso,final AtomicReference<String> xml_path,final AtomicReference<Preamble> version) throws Exception, FileNotFoundException {
        this.xml_path = xml_path;
        this.version = version;
        this.complete_filename_template = complete_filename_template;
        this.complete_filename_iso = complete_filename_iso;
        validate();
        this.prefix = XMLUtil.getPrefix(complete_filename_template);

        File file_template = new File(complete_filename_template);
        File file_iso = new File(complete_filename_iso);

        Logs.application(TAG, "----------------------------------------------------------------------------------------------------");
        FileInputStream fi_template = new FileInputStream(file_template);
        FileInputStream fi_iso = new FileInputStream(file_iso);
        byte[] lenght_template = new byte[(int) file_template.length()];
        byte[] lenght_iso = new byte[(int) file_iso.length()];
//        byte[] ba2 = new byte[(int) file_template.length()];

        fi_template.read(lenght_template);
        fi_iso.read(lenght_iso);

        VTDGen vtdGen_template = new VTDGen();
        VTDGen vtdGen_iso = new VTDGen();

        vtdGen_template.setDoc(lenght_template);
        vtdGen_template.parse(true);

        vtdGen_iso.setDoc(lenght_iso);
        vtdGen_iso.parse(true);

        vtdNav_template = vtdGen_template.getNav();
        vtdNav_iso = vtdGen_iso.getNav();

//        AutoPilot ap = new AutoPilot();
        ap_template.bind(vtdNav_template);
        ap_iso.bind(vtdNav_iso);

        CodeList.setCODELISTQUERY(getCodeListCodedQuery());
        Logs.application(TAG, "---------------------------------------------------------------------");
        Logs.application(TAG, CodeList.CODELISTQUERY);
        Logs.application(TAG, "---------------------------------------------------------------------");
        CodeList.setDEFAULT_URL(getDefaultEndPointSparql());
        Sparql.setDEFAULT_URL(getDefaultEndPointSparql());
        Logs.application(TAG, CodeList.DEFAULT_URL);
        Logs.application(TAG, "---------------------------------------------------------------------");

        ap_iso.declareXPathNameSpace("gmd", "http://www.isotc211.org/2005/gmd");
        ap_iso.declareXPathNameSpace("gco", "http://www.isotc211.org/2005/gco");
        ap_iso.declareXPathNameSpace("gml", "http://www.opengis.net/gml/3.2");
        ap_iso.declareXPathNameSpace("xlink", "http://www.w3.org/1999/xlink");
        Logs.application(TAG, "---------------------------------------------------------------------");
        
        xml_path.set(getXMLTransformation());
        version.set(getEdiPreamble());
        Logs.application(TAG, xml_path.get() );
        Logs.application(TAG, "---------------------------------------------------------------------");
        endPointTypes = getPreQuery();
        sparqls = getSparql(endPointTypes);
        codeLists = getCodeList(endPointTypes);

        if (endPointTypes == null) {
            throw new Exception("NO ENDPOINTS");
        }

        if (sparqls == null) {
            throw new Exception("NO QUERY SPARQL");
        }
        if (codeLists == null) {
            throw new Exception("NO QUERY CODELIST");
        }

    }

    private void validate() throws Exception {
        if (Util.isNullOrEmpty(complete_filename_template)) {
            throw new Exception("ElementEdml TEMPLATE : Id is null");
        }
        File f = new File(complete_filename_template);
        if (!f.exists()) {
            throw new Exception("ElementEdml TEMPLATE : File does not exist");
        }
        if (Util.isNullOrEmpty(complete_filename_iso)) {
            throw new Exception("ElementEdml ISO : Id is null");
        }
        f = new File(complete_filename_iso);
        if (!f.exists()) {
            throw new Exception("ElementEdml ISO : File does not exist");
        }
    }

    public int getPositionIgnorePrefix(String to_search) throws NavException {
        int exit = -1;
        Set<String> names = XMLUtil.stringsToFind(prefix, to_search);
        Iterator<String> iterator = names.iterator();
        String name = null;
        while ((iterator.hasNext()) && (exit == -1)) {
            name = iterator.next();

            exit = vtdNav_template.getAttrVal(name);
            Logs.application(TAG, "id : " + exit);
        }
        return exit;
    }

    public String getCodeListCodedQuery() throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        String exit = null;
        ap_template.selectXPath("//settings/codelistQuery");
        int result = -1;

        result = ap_template.evalXPath();
        if (result != -1) {
            Logs.application(TAG, "POSIZIONE : " + result + " ");
            Logs.application(TAG, "Element name ==> " + vtdNav_template.toString(result));
            int t = vtdNav_template.getText(); // get the index of the text (char data or CDATA)
            if (t != -1) {
                exit = vtdNav_template.toNormalizedString(t);
//               Logs.application(TAG," Text N==> " + vtdNav_template.toNormalizedString(t));
//               Logs.application(TAG," Text S==> " + vtdNav_template.toString(t));
            }
            System.out.println("\n ============================== ");
        }

//        vtdNav_template.toElement(VTDNav.PARENT);
//        vtdNav_template.toElement(VTDNav.PARENT);
//        vtdNav_template.toElement(VTDNav.PARENT);
//            
        return exit;
    }

    public String getDefaultEndPointSparql() throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        String exit = null;
        ap_template.selectXPath("//settings/sparqlEndpoint");
        int result = -1;

        result = ap_template.evalXPath();
        if (result != -1) {
            Logs.application(TAG, "POSIZIONE : " + result + " ");
            Logs.application(TAG, "Element name ==> " + vtdNav_template.toString(result));
            int t = vtdNav_template.getText(); // get the index of the text (char data or CDATA)
            if (t != -1) {
                exit = vtdNav_template.toNormalizedString(t);
//               Logs.application(TAG," Text N==> " + vtdNav_template.toNormalizedString(t));
//               Logs.application(TAG," Text S==> " + vtdNav_template.toString(t));
            }
            System.out.println("\n ============================== ");
        }

//        vtdNav_template.toElement(VTDNav.PARENT);
//        vtdNav_template.toElement(VTDNav.PARENT);
//        vtdNav_template.toElement(VTDNav.PARENT);
//            
        return exit;
    }

    public List<EndPointType> getPreQuery() throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        List<EndPointType> exit = Lists.newArrayList();
        ap_template.selectXPath("//endpointTypes/endpointType");
        int result = -1;
        while ((result = ap_template.evalXPath()) != -1) {
            Logs.application(TAG, result + "");
            int id = getPositionIgnorePrefix("id");
            int method = vtdNav_template.getAttrVal("method");
            int queryParameter = vtdNav_template.getAttrVal("queryParameter");

            EndPointType pq = new EndPointType(vtdNav_template.toNormalizedString(id));
            pq.setQueryParameter(vtdNav_template.toNormalizedString(queryParameter));
            pq.setMethod(vtdNav_template.toNormalizedString(method));

//            
            vtdNav_template.toElement(VTDNav.FIRST_CHILD, "parameters");
            vtdNav_template.toElement(VTDNav.LAST_CHILD, "parameter");

            int lastchild = vtdNav_template.getCurrentIndex();

            Logs.application(TAG, "LastChild index : " + lastchild);

            vtdNav_template.toElement(VTDNav.PARENT);

            vtdNav_template.toElement(VTDNav.FIRST_CHILD, "parameter");
            boolean last = false;

            while ((vtdNav_template.getCurrentIndex() != -1) && (!last)) {
                if (lastchild == vtdNav_template.getCurrentIndex()) {
                    last = true;
                }

                int name = vtdNav_template.getAttrVal("name");
                int value = vtdNav_template.getAttrVal("value");
                pq.addParameter(vtdNav_template.toNormalizedString(name), vtdNav_template.toNormalizedString(value));
                Logs.application(TAG, " ==> FOUND");
                vtdNav_template.toElement(VTDNav.NEXT_SIBLING);
            }
            Logs.application(TAG, pq.toString());
            exit.add(pq);
            vtdNav_template.toElement(VTDNav.PARENT);
            vtdNav_template.toElement(VTDNav.PARENT);
        }
        return exit;
    }

    public String getXMLTransformation() throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        String exit = null;
        String to_remove = "file://";
        ap_template.selectXPath("//xsltChain/xslt");
        int result = -1;
        System.out.println("\n ==++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++============================ ");
        result = ap_template.evalXPath();
        if (result != -1) {
            Logs.application(TAG, "POSIZIONE : " + result + " ");
            Logs.application(TAG, "Element name ==> " + vtdNav_template.toString(result));
            int t = vtdNav_template.getText(); // get the index of the text (char data or CDATA)
            if (t != -1) {
                exit = vtdNav_template.toNormalizedString(t);
//               Logs.application(TAG," Text N==> " + vtdNav_template.toNormalizedString(t));
//               Logs.application(TAG," Text S==> " + vtdNav_template.toString(t));
            }
            System.out.println("\n ============================== ");
        }
        if (exit != null) {
            System.out.println("- it contains prefix " + to_remove);
            if (exit.contains(to_remove)) {
                exit =  exit.replace(to_remove, "");
            }
        }
        return exit;
    }
    public Preamble getEdiPreamble() throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        String resultString = null;
        String to_remove = "file://";
        ap_template.selectXPath("//edimlPreamble");
        int result = -1;
        System.out.println("\n ==++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++============================ ");
        result = ap_template.evalXPath();
        if (result != -1) {
            Logs.application(TAG, "POSIZIONE : " + result + " ");
            Logs.application(TAG, "Element name ==> " + vtdNav_template.toString(result));
            int t = vtdNav_template.getText(); // get the index of the text (char data or CDATA)
            if (t != -1) {
                resultString = vtdNav_template.toNormalizedString(t);
//               Logs.application(TAG," Text N==> " + vtdNav_template.toNormalizedString(t));
//               Logs.application(TAG," Text S==> " + vtdNav_template.toString(t));
            }
            System.out.println("\n ============================== ");
        }
        if (resultString != null) {
            System.out.println("- it contains prefix " + to_remove);
            if (resultString.contains(to_remove)) {
                resultString =  resultString.replace(to_remove, "");
            }
        }
        
        String versionI = "<version>";
        String versionF = "</version>";
        String versionout = "";
        int posI = resultString.indexOf(versionI) + versionI.length();
        int posF =resultString.indexOf(versionF);
        
        String versione =resultString.substring(posI, posF);
        
        Logs.domain(TAG, "VERSION -> " + resultString.substring(posI, posF));
        
        String templateI = "<template>";
        String templateF = "</template>";
        
        posI =resultString.indexOf(templateI) + templateI.length();
        posF =resultString.indexOf(templateF);
        
        Logs.domain(TAG, "TEMPLATE -> " + resultString.substring(posI, posF));
        
        String template =resultString.substring(posI, posF);
        
        String fileIDI = "<fileId>";
        String fileIDF = "</fileId>";
        
        posI = resultString.indexOf(fileIDI) + fileIDI.length();
        posF =resultString.indexOf(fileIDF);
        
        Logs.domain(TAG, "FILEID -> " + resultString.substring(posI, posF));
        
        String fileID =resultString.substring(posI, posF);
        
        String fileUriI = "<fileUri>";
        String fileUriF = "</fileUri>";
        
        posI = resultString.indexOf(fileUriI) + fileUriI.length();
        posF = resultString.indexOf(fileUriF);
        
        Logs.domain(TAG, "FILEURI -> " + resultString.substring(posI, posF));
        
        String fileUri =resultString.substring(posI, posF);
        
        return new Preamble(versione, template, fileID, fileUri);
    }

    public List<CodeList> getCodeList(List<EndPointType> endpoints) throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        List<CodeList> exit = Lists.newArrayList();
        int counter = 0;
        ap_template.selectXPath("//datasources/codelist");
        int result = -1;
        while ((result = ap_template.evalXPath()) != -1) {
            counter++;
            Logs.application(TAG, "POSITION : " + result + "");

            int id = getPositionIgnorePrefix("id");
            Logs.application(TAG, "POSIZIONE ID : " + id + "");
            int endpointType = vtdNav_template.getAttrVal("endpointType");

            String endPointType_value = vtdNav_template.toNormalizedString(endpointType);
            Logs.application(TAG, "endPointType_value " + endPointType_value);

            Optional<EndPointType> endpointOptional = endpoints.stream()
                    .filter(t -> t.getId().equals(endPointType_value))
                    .findAny();

            EndPointType to_insert = null;
            if (endpointOptional.isPresent()) {
                to_insert = endpointOptional.get();
            }

            String uri = null;
            vtdNav_template.toElement(VTDNav.FIRST_CHILD, "uri");
            int uri_value_pos = vtdNav_template.getText();
            if (uri_value_pos != -1) {
                uri = vtdNav_template.toString(uri_value_pos);
                vtdNav_template.toElement(VTDNav.PARENT);
                Logs.application(TAG, "URI  ==> [" + uri_value_pos + "] " + uri);
            } else {
                Logs.application(TAG, "NOT FOUND URI");
            }
            String url = null;
            vtdNav_template.toElement(VTDNav.FIRST_CHILD, "url");
            int url_value_pos = vtdNav_template.getText();
            if (url_value_pos != -1) {
                url = vtdNav_template.toString(url_value_pos);
                Logs.application(TAG, "URL  ==> [" + url_value_pos + "] " + url);
                vtdNav_template.toElement(VTDNav.PARENT);
            } else {
                Logs.application(TAG, "NOT FOUND URl");
            }

            CodeList pq = new CodeList(vtdNav_template.toNormalizedString(id), to_insert, uri, url);
            Logs.application(TAG, pq.toString());
            exit.add(pq);

        }
        Logs.application(TAG, "************************************************************************************************");
        Logs.application(TAG, "COUNTER : " + exit + "");
        Logs.application(TAG, "************************************************************************************************");
        return exit;
    }

    public List<Sparql> getSparql(List<EndPointType> endpoints) throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {
        List<Sparql> exit = Lists.newArrayList();
        int counter = 0;
        Logs.application(TAG, "---------GET SPARQL END POINTS ------------------------------------------------------------------------------------------------");
        ap_template.selectXPath("//datasources/sparql");
        int result = -1;
        while ((result = ap_template.evalXPath()) != -1) {

            Logs.application(TAG, "-------------------------------------------------------------------------------------------------------------------------------");
            counter++;
            Logs.application(TAG, "POSITION : " + result + "");

            int id = getPositionIgnorePrefix("id");
            Logs.application(TAG, "POSIZIONE ID : " + id + "");
            int endpointType = vtdNav_template.getAttrVal("endpointType");
            String endPointType_value = vtdNav_template.toNormalizedString(endpointType);
            Logs.application(TAG, "endPointType_value " + endPointType_value);

            Optional<EndPointType> endpointOptional = endpoints.stream()
                    .filter(t -> t.getId().equals(endPointType_value))
                    .findAny();

            EndPointType to_insert = null;
            if (endpointOptional.isPresent()) {
                to_insert = endpointOptional.get();
            }

            String query = null;
            vtdNav_template.toElement(VTDNav.FIRST_CHILD, "query");
            int query_value_pos = vtdNav_template.getText();
            if (query_value_pos != -1) {
                query = vtdNav_template.toString(query_value_pos);
                vtdNav_template.toElement(VTDNav.PARENT);
                Logs.application(TAG, "QUERY  ==> [" + query_value_pos + "] " + query);
            } else {
                Logs.application(TAG, "NOT FOUND QUERY");
            }
            vtdNav_template.toElement(VTDNav.FIRST_CHILD, "url");

            String sparqlEndpoint = null;
            int sparqlEndpoint_pos = vtdNav_template.getText();
            if (sparqlEndpoint_pos != -1) {
                sparqlEndpoint = vtdNav_template.toString(sparqlEndpoint_pos);
                vtdNav_template.toElement(VTDNav.PARENT);
                Logs.application(TAG, "sparqlEndpoint  ==> [" + sparqlEndpoint_pos + "] " + sparqlEndpoint);
                to_insert.setSparqlEndpoint(sparqlEndpoint);
            } else {
                Logs.application(TAG, "NOT FOUND SPARQL");
            }

            Sparql sparql = new Sparql(vtdNav_template.toNormalizedString(id), to_insert, query);
            Logs.application(TAG, sparql.toString());
            exit.add(sparql);
        }
        Logs.application(TAG, "COUNTER : " + counter + "");
        Logs.application(TAG, "---------GET SPARQL END POINTS END---------------------------------------------------------------------------------------------");
        Logs.application(TAG, "-------------------------------------------------------------------------------------------------------------------------------");
        return exit;
    }

    //MAIN METHOD TO RETRIEVE ELEMENT FOR THE EDML
    public List<PreTemplateElement> getElemetsEdml() throws IOException, EOFException, EntityException, ParseException, XPathParseException, XPathEvalException, NavException, Exception {

        List<PreTemplateElement> exit = Lists.newArrayList();
        ap_template.selectXPath("//element");

        int count = 0;

        int result = -1;

        while ((result = ap_template.evalXPath()) != -1) {

            // ?
            count++;
            count++;

            int found_position = getPositionIgnorePrefix("id");

            if (found_position == -1) {
                Logs.application(TAG, "ID NOT FOUND ");
            } else {

                boolean isMandatory = false;

                Logs.application(TAG, "ID  ==> [" + found_position + "] " + vtdNav_template.toNormalizedString(found_position) + "    ");

                PreTemplateElement elementEdml = new PreTemplateElement(vtdNav_template.toNormalizedString(found_position));

                int isMandatory_pos = vtdNav_template.getAttrVal("isMandatory");
                int isMultiple_pos = vtdNav_template.getAttrVal("isMultiple");

                if (isMandatory_pos != -1) {
                    String value = vtdNav_template.toNormalizedString(isMandatory_pos);
                    Logs.application(TAG, "-- is Mandatory_pos  ==> [" + isMandatory_pos + "] " + value + "    ");
                    elementEdml.setMandatory(value);
                    try {
                        isMandatory = Boolean.parseBoolean(value);
                    } catch (Exception e) {
                        Logs.application(TAG, "-- FAIL TO PARSE ! : " + e.getMessage());
                    }
                }
                if (isMultiple_pos != -1) {
                    String value = vtdNav_template.toNormalizedString(isMultiple_pos);
                    Logs.application(TAG, "-- is Multiple_pos  ==> [" + isMultiple_pos + "] " + value + "    ");
                    elementEdml.setIsMultiple(Boolean.parseBoolean(value));
                    try {
                        isMandatory = Boolean.parseBoolean(value);
                    } catch (Exception e) {
                        Logs.application(TAG, "-- FAIL TO PARSE Multiple! : " + e.getMessage());
                    }
                }

                vtdNav_template.toElement(VTDNav.FIRST_CHILD, "hasRoot");

                // HERE I FOUND THE HASROOT I NEED TO CHECK IF THE ITEM HAS A RELATIVE PATH OR AN ABOSOLUTE PATH.
                int hasroot_pos = vtdNav_template.getText();

                if (hasroot_pos != -1) {
                    Logs.application(TAG, " hasRoot ==> [" + hasroot_pos + "] " + vtdNav_template.toString(hasroot_pos));
                    elementEdml.setRoot(vtdNav_template.toString(hasroot_pos));

                } else {
                    Logs.application(TAG, " hasRoot ==> NOT FOUND");
                }

                vtdNav_template.toElement(VTDNav.PARENT);

                vtdNav_template.toElement(VTDNav.FIRST_CHILD);

                Logs.application(TAG, "dep ==> " + vtdNav_template.getCurrentDepth());

                while (!vtdNav_template.matchElement("produces")) {
                    vtdNav_template.toElement(VTDNav.NEXT_SIBLING);
                }

                // here i start to process items 
                if (vtdNav_template.matchElement("produces")) {

                    Logs.application(TAG, "- PRODUCES FOUND !!!!!!!!!!!!!!!!!!!!!");
                    int aa = vtdNav_template.getAttrCount();
                    vtdNav_template.toElement(VTDNav.LAST_CHILD);
                    int lastchild = vtdNav_template.getCurrentIndex();
                    vtdNav_template.toElement(VTDNav.PARENT);

                    Logs.application(TAG, "- AA " + aa + " lastchild " + lastchild);

                    vtdNav_template.toElement(VTDNav.FIRST_CHILD);

                    if (lastchild != -1) {
                        boolean last = false;
                        while ((vtdNav_template.getCurrentIndex() != -1) && (!last)) {
                            if ((vtdNav_template.matchElement("item"))) {

                                // HERE I'VE FOUND THE ITEM
                                boolean isAutoCompletion = false;
                                boolean isCodeList = false;
                                boolean isToSearch = false;
                                boolean isRef = false;
                                Logs.application(TAG, "------------NEW ITEM FOUND----------------------------------------------------------------------------------------------------------------------");

                                found_position = getPositionIgnorePrefix("id");

                                if (found_position == -1) {
                                    Logs.application(TAG, "-- ID NOT FOUND ");
                                } else {
                                    Logs.application(TAG, "-- ID  ==> [" + found_position + "] " + vtdNav_template.toNormalizedString(found_position) + "    ");

                                    PreTemplateItem item = new PreTemplateItem(vtdNav_template.toNormalizedString(found_position));

                                    int isLanguageNeutral_pos = vtdNav_template.getAttrVal("isLanguageNeutral");
                                    if (isLanguageNeutral_pos != -1) {
                                        Logs.application(TAG, " isLanguageNeutral_pos ==> [" + isLanguageNeutral_pos + "] " + vtdNav_template.toString(isLanguageNeutral_pos));
                                        item.setIsLanguageNeutral(vtdNav_template.toString(isLanguageNeutral_pos));

                                    } else {
                                        Logs.application(TAG, " hasRoot ==> NOT FOUND");
                                    }

                                    int hasIndex_pos = vtdNav_template.getAttrVal("hasIndex");
                                    if (hasIndex_pos != -1) {
                                        Logs.application(TAG, " hasIndex_pos ==> [" + hasIndex_pos + "] " + vtdNav_template.toString(hasIndex_pos));
                                        item.setHasIndex(vtdNav_template.toString(hasIndex_pos));

                                    } else {
                                        Logs.application(TAG, " hasIndex_pos ==> NOT FOUND");
                                    }

                                    int show_pos = vtdNav_template.getAttrVal("show");
                                    if (show_pos != -1) {
                                        Logs.application(TAG, " isShow_pos ==> [" + show_pos + "] " + vtdNav_template.toString(show_pos));
                                        item.setShow(vtdNav_template.toString(show_pos));

                                    } else {
                                        Logs.application(TAG, " show ==> NOT FOUND");
                                    }

                                    int isFixed_pos = vtdNav_template.getAttrVal("isFixed");
                                    if (isFixed_pos != -1) {
                                        Logs.application(TAG, " isFixed_pos ==> [" + isFixed_pos + "] " + vtdNav_template.toString(isFixed_pos));
                                        item.setFixed(vtdNav_template.toString(isFixed_pos));

                                    } else {
                                        Logs.application(TAG, " isFixed_pos ==> NOT FOUND");
                                    }

                                    int hasDatatype_pos = vtdNav_template.getAttrVal("hasDatatype");
                                    if (hasDatatype_pos != -1) {
                                        String dataType = vtdNav_template.toString(hasDatatype_pos);
                                        Logs.application(TAG, " hasDatatype ==> [" + hasDatatype_pos + "] " + dataType);
                                        item.setDatatype(dataType);
                                        if (datatypes.contains(dataType)) {
                                            if (dataType.equals(DataType.ref.toString())) {
                                                Logs.application(TAG, " hasDatatype ==> REF");
                                                isRef = true;
                                            } else {
                                                isToSearch = true;
                                                if (dataType.equals(DataType.autoCompletion.toString())) {
                                                    Logs.application(TAG, " hasDatatype ==> AUTOCOMPLETION");
                                                    isAutoCompletion = true;
                                                } else if (dataType.equals(DataType.codelist.toString())) {
                                                    isCodeList = true;
                                                    Logs.application(TAG, " hasDatatype ==> CODELIST");
                                                }
                                            }
                                        }

                                    } else {
                                        Logs.application(TAG, " hasDatatype ==> NOT FOUND");
                                    }

                                    int datasource_pos = vtdNav_template.getAttrVal("datasource");
                                    if (datasource_pos != -1) {

                                        String datasource_value = vtdNav_template.toString(datasource_pos);
                                        if (isAutoCompletion) {
                                            Logs.application(TAG, "-----------------------------------------------------------------------------------------------------");
                                            Logs.application(TAG, AUTOCOMPLETION);
                                            Logs.application(TAG, "-----------------------------------------------------------------------------------------------------");
                                            Logs.application(TAG, "Datasourcee ==> [" + datasource_pos + "] " + vtdNav_template.toString(datasource_pos));
                                            item.setDatasource(vtdNav_template.toString(datasource_pos));
                                            Optional<Sparql> sparql_optional = sparqls.stream()
                                                    .filter(t -> t.getId().equals(datasource_value))
                                                    .findAny();
                                            if (sparql_optional.isPresent()) {
                                                item.setSparql(sparql_optional.get());
                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++");
                                                Logs.application(TAG, "FOUND");
                                                Logs.application(TAG, "EndPoint: " + sparql_optional.get());
                                                Logs.application(TAG, "-");
                                                Logs.application(TAG, item.toString());
                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++");
                                            } else {
                                                Logs.application(TAG, "sparql_optional NOT FOUND");
                                            }

                                        } else if (isCodeList) {
                                            Logs.application(TAG, "-----------------------------------------------------------------------------------------------------");
                                            Logs.application(TAG, "CODELIST");
                                            Logs.application(TAG, "-----------------------------------------------------------------------------------------------------");
                                            Logs.application(TAG, "Datasourcee ==> [" + datasource_pos + "] " + vtdNav_template.toString(datasource_pos));
                                            item.setDatasource(vtdNav_template.toString(datasource_pos));
                                            Optional<CodeList> codeList_optional = codeLists.stream()
                                                    .filter(t -> t.getId().equals(datasource_value))
                                                    .findAny();
                                            if (codeList_optional.isPresent()) {
                                                item.setCodeList(codeList_optional.get());
                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++");
                                                Logs.application(TAG, "FOUND");
                                                Logs.application(TAG, codeList_optional.get().toString());
                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++");
                                            } else {
                                                Logs.application(TAG, "codeLiost_optional NOT FOUND");
                                            }

                                        } else {
                                            Logs.application(TAG, " datasourcee ==> [" + datasource_pos + "] " + vtdNav_template.toString(datasource_pos));
                                            item.setDatasource(vtdNav_template.toString(datasource_pos));
                                        }

                                    } else {
                                        Logs.application(TAG, " datasource ==> NOT FOUND");
                                    }

                                    // HERE I'VE TO CHECK IF IT IS A RELATIVE PATH .... I'WILL PUT THIS CHECK IN THE CLASS XMLUtil
                                    vtdNav_template.toElement(VTDNav.FIRST_CHILD, "hasPath");
                                    int hasPath_pos = vtdNav_template.getText();
                                    if (hasPath_pos != -1) {

                                        String found = vtdNav_template.toString(hasPath_pos);
                                        Logs.application(TAG, " hasPath ==> [" + hasPath_pos + "] : " + found);

                                        // HERE I PUT ALWAYS AN ABSOLUTE PATH
                                        item.setPath(XMLUtil.verifyIfThePathIsAbsoluteAndReturnTheRightValue(elementEdml.getRoot(), found));
                                        vtdNav_template.toElement(VTDNav.PARENT);

//                                        ap_iso.selectXPath(found);
                                        ap_iso.selectXPath(XMLUtil.verifyIfThePathIsAbsoluteAndReturnTheRightValue(elementEdml.getRoot(), found));
                                        if (isToSearch) {
                                            Logs.application(TAG, "-IT IS TO SEARCH!");
                                            Logs.application(TAG, "-XPATH : " + found);
                                            int result2;
                                            while ((result2 = ap_iso.evalXPath()) != -1) {
                                                Logs.application(TAG, "-result2 : " + result2);

                                                if (result2 != -1) {
                                                    if (found.contains("@")) {

                                                        String value = vtdNav_iso.toNormalizedString(result2);
                                                        int pos = vtdNav_iso.getAttrVal(value);
                                                        if (pos != -1) {
                                                            Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                            Logs.application(TAG, "[DA RICERCARE @]  datasource ==> [" + pos + "] ");
                                                            Logs.application(TAG, "[DA RICERCARE @]  datasource ==> [" + result2 + "] " + vtdNav_iso.toNormalizedString(result2) + " | " + vtdNav_iso.toString(pos));
                                                            Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                            item.addToSearch(vtdNav_iso.toString(pos));
                                                            item.setValue(vtdNav_iso.toString(pos));

                                                        } else {
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            Logs.application(TAG, "[DA RICERCARE @] ERRORE");
                                                            Logs.application(TAG, found);
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                        }
                                                    } else {
                                                        int pos = vtdNav_iso.getText();
                                                        if (pos != -1) {
                                                            Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                            Logs.application(TAG, "[DA RICERCARE]  datasource ==> [" + pos + "] ");
                                                            Logs.application(TAG, "[DA RICERCARE]  datasource ==> [" + result2 + "] " + vtdNav_iso.toNormalizedString(result2) + " | " + vtdNav_iso.toString(pos));
                                                            Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                            item.addToSearch(vtdNav_iso.toString(pos));
                                                            item.setValue(vtdNav_iso.toString(pos));
                                                        } else {
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            Logs.application(TAG, "[DA RICERCARE] ERRORE");
                                                            Logs.application(TAG, found);
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                        }
                                                    }

                                                } else {
                                                    Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                    Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                    Logs.application(TAG, "[DA RICERCARE] NON TROVATO : " + result2);
                                                    Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                    Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

                                                }
                                            }

                                        } else {
                                            if (found.contains("@")) {
                                                int result2;
                                                if (!isRef) {
                                                    while ((result2 = ap_iso.evalXPath()) != -1) {

                                                        if (result2 != -1) {

                                                            String value = vtdNav_iso.toNormalizedString(result2);
                                                            int pos = vtdNav_iso.getAttrVal(value);
                                                            if (pos != -1) {
                                                                Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                                Logs.application(TAG, "[NON DA RICERCARE @] TROVATO : " + result2);
                                                                Logs.application(TAG, "[NON DA RICERCARE @]  datasource ==> [" + result2 + "] " + vtdNav_iso.toNormalizedString(result2) + " | " + vtdNav_iso.toString(pos));
                                                                Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                                Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                                item.setValue(vtdNav_iso.toString(pos));
//                                                  
                                                            } else {
                                                                Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                                Logs.application(TAG, "[NON DA RICERCARE @ ] ERRORE");
                                                                Logs.application(TAG, found);
                                                                Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                                Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            }
                                                        } else {
                                                            Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                            Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                            Logs.application(TAG, "[NON DA RICERCARE] NON TROVATO : " + result2);
                                                            Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                            Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                        }
                                                    }
                                                }
                                            } else {
//                                                int result2 = ap_iso.evalXPath();
                                                int result2;
                                                if (!isRef) {
                                                    while ((result2 = ap_iso.evalXPath()) != -1) {

                                                        if (result2 != -1) {
                                                            int pos = vtdNav_iso.getText();
                                                            if (pos != -1) {
                                                                Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                                Logs.application(TAG, "[NON DA RICERCARE] TROVATO : " + result2);
                                                                Logs.application(TAG, "[NON DA RICERCARE]  datasource ==> [" + result2 + "] " + vtdNav_iso.toNormalizedString(result2) + " | " + vtdNav_iso.toString(pos));
                                                                Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                                Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                                item.setValue(vtdNav_iso.toString(pos));
//                                                        item.setValue(vtdNav_iso.toString(pos));
                                                            } else {
                                                                Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                                Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                                Logs.application(TAG, "[NON DA RICERCARE] ERRORE");
                                                                Logs.application(TAG, found);
                                                                Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                                Logs.application(TAG, "_°°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°_°___°_°_°_°_°__°_°_°_°_°");
                                                            }
                                                        } else {
                                                            Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                            Logs.application(TAG, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                                            Logs.application(TAG, "[NON DA RICERCARE] NON TROVATO : " + result2);
                                                            Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                            Logs.application(TAG, "-------------------------------------------------------------------------------------------------");
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                    } else {
                                        Logs.application(TAG, " hasPath ==> NOT FOUND");
                                    }

                                    vtdNav_template.toElement(VTDNav.FIRST_CHILD, "hasValue");
                                    int hasValue_pos = vtdNav_template.getText();
                                    if (hasValue_pos != -1) {

                                        if (Util.isNullOrEmpty(item.getValue())) {
                                            Logs.application(TAG, " hasValue ==> [" + hasValue_pos + "] " + vtdNav_template.toString(hasValue_pos));
                                            item.setValue(vtdNav_template.toString(hasValue_pos));
                                        }
                                        vtdNav_template.toElement(VTDNav.PARENT);

                                    } else {
                                        Logs.application(TAG, " hasValue ==> NOT FOUND");
                                    }
                                    Logs.application(TAG, " ITEM  ----------");
                                    Logs.application(TAG, item.toString());

                                    elementEdml.addItem(item);
                                }
                            } else {
                                Logs.application(TAG, "-- NOT ITEM   ******************************************************************************");
                            }
                            if (lastchild == vtdNav_template.getCurrentIndex()) {
                                last = true;
                            }
                            vtdNav_template.toElement(VTDNav.NEXT_SIBLING);

                        }
//                        }
                    }
                    vtdNav_template.toElement(VTDNav.PARENT);
                } else {
                    Logs.application(TAG, "- PRODUCES NOT FOUND");
                }

                vtdNav_template.toElement(VTDNav.PARENT);
//                Logs.application(TAG,"=====> " + elementEdml.toString());

                exit.add(elementEdml);
            }

//            
//            vn2.toElement(VTDNav.FIRST_CHILD, "hasPath");
//            int t = vn2.getText();
//            if (t != -1) //test to see if the element has text node or not 
//            {
//                Logs.application(TAG," Path ==> [" + t + "] " + vn2.toString(t) + " | ");
//            }
//            vn2.toElement(VTDNav.PARENT);
//
//            vn2.toElement(VTDNav.PARENT);
//            vn2.toElement(VTDNav.PARENT);
//
//            Logs.application(TAG," vn2.getAttrCount() ==> [" + vn2.getAttrCount() + "] ");
//            int x = vn2.getAttrVal("xml:id");
//            Logs.application(TAG," id ==> [" + x + "] ");
//
//            vn2.toElement(VTDNav.FIRST_CHILD, "label");
//
//            t = vn2.getText();
//            Logs.application(TAG," Position ==> [" + t + "] ");
//            if (t != -1) //test to see if the element has text node or not 
//            {
//                Logs.application(TAG," label ==> [" + t + "] " + vn2.toString(t) + " | ");
//            }
            Logs.application(TAG, "\n ==================================================================================================================================================================================== ");
        }
//
//        File file = new File(path + UUID.randomUUID().toString() + ".xml");
//        ObjectMapper mapper = new XmlMapper();
//        mapper.enable(SerializationFeature.INDENT_OUTPUT);
//        Logs.application(TAG,mapper.writeValueAsString(template));
//
//        mapper.writeValue(file, template);
////        Logs.application(TAG,xml);
////            XmlMapper xmlMapper = new XmlMapper();
////            xmlMapper.writeValue(file, template);
//        ap_template.resetXPath();
        return exit;
    }

}
