/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lf.cnr.util;


import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LUCA FRIGERIO
 */
public class Configure {

    public static String DIRECTORY = "df.directory";
    
    public static String PRINTERMANAGERADMIN = "printer.amministratori";
    public static String DOMAIN_DEBUGMODE = "dd.domaindebugmode";
    public static String WEB_DEBUGMODE = "dd.webdebugmode";
    public static String APPLICATION_DEBUGMODE = "dd.applicationdebugmode";
    public static String JPA_DEBUGMODE = "dd.jpadebugmode";
    public static String SERVLET_DEBUGMODE = "dd.servletdebugmode";
    public static String CODICE_RIFERIMENTO = "dd.codiceRiferimento";
    public static String PORTA_OPENOFFICE = "dd.openOfficePort";
    public static String DIRECTORY_EXCEL = "dd.pathExcell";
    public static String DIRECTORY_PDF = "dd.pathPDF";
    public static String UTIL_DEBUGMODE = "dd.util";
    public static String PDF_PATH = "dd.pdfpath";
    public static String CALCOLI_PATH = "dd.calcoli";
    public static String CSV_PATH = "dd.csv_path";
    public static String HELP = "dd.help";
    public static String SHAPE1 = "dd.shapecolor1";
    public static String SHAPE2 = "dd.shapecolor2";
    public static String SHAPE3 = "dd.shapecolor3";
    public static String SHAPE4 = "dd.shapecolor4";
    public static String SHAPE5 = "dd.shapecolor5";
    public static String IS_TEST = "dd.isTest";
    static Properties m_prop = new Properties();
    static Configure m_theInstance = new Configure();

    public static Configure getInstance() {
        return m_theInstance;
    }

    public String getProperty(String prop) {
        return m_prop.getProperty(prop);
    }

    private Configure() {
        try {
            m_prop.load(getClass().getClassLoader().getResourceAsStream("configure.properties"));
        } catch (IOException ex) {
            Logger.getLogger(Configure.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}



