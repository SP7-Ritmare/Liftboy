/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lf.cnr.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.TimeUnit; 
 

/**
 *
 * @author Luca Frigerio
 */
public class DateUtil {

    public static final String ORAMINUTISECONDIGIORNOMESEANNO = "HH:mm:ss dd/MM/yyyy";
    public static final String ANNOMESEGIORNOORAMINUTOSECONDO = "yyyy-MM-dd HH:mm:ss";
    public static final String ANNOMESEGIORNO = "yyyy-MM-dd";
    public static final String ANNOMESEGUORNOTORAMINUTOSECONDO = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String HORAMINUTOSECONDO = "HH:mm:ss";
    public static final String ORAMINUTIGIORNOMESEANNO = "HH:mm dd/MM/yyyy";
    public static final String GIORNOMESEANNO = "dd/MM/yyyy";
    public static final String ORAMINUTIGIORNOMESEANNOMENO = "HH-mm-ss-dd-MM-yyyy";
    public static final String ANNOMESEGIORNOORAMINUTISECONDO = "yyyy-MM-dd-HH-mm-ss";
    public static final String MESEANNO = "MM-yyyy";
    public static final String ANNO = "yyyy";
    public static final String TAG = "DateUtil";

    public static String convertToString(Date date, String format) {
        String exit = "Error parsing date";
        if ((format != null) && (date != null)) {
            SimpleDateFormat date_format = new SimpleDateFormat(format);
            exit = date_format.format(date);
        }
        return exit;

    }
    
    public static String currentDate() {
        return convertToString(new Date(), ORAMINUTISECONDIGIORNOMESEANNO);
        
    }
    public static String currentDateSafe() {
        return convertToString(new Date(), ANNOMESEGIORNOORAMINUTISECONDO);
        
    }
    
    
    public String differenceBetweenDate(Date from, Date to) {
        long millis = to.getTime() - from.getTime();
        
        return TimeUnit.MILLISECONDS.toDays(millis) +  " days " 
               + TimeUnit.MILLISECONDS.toHours(millis) +"h "
               + TimeUnit.MILLISECONDS.toMinutes(millis) +"m "
               + TimeUnit.MILLISECONDS.toSeconds(millis) +"s "
               + TimeUnit.MILLISECONDS.toMillis(millis) +"millis";
        
        
    }
    public static String timeFromNow(long from) {
        long millis = System.currentTimeMillis() - from;
        
        return TimeUnit.MILLISECONDS.toDays(millis) +  " days " 
               + TimeUnit.MILLISECONDS.toHours(millis) +"h "
               + TimeUnit.MILLISECONDS.toMinutes(millis) +"m "
               + TimeUnit.MILLISECONDS.toSeconds(millis) +"s "
               + TimeUnit.MILLISECONDS.toMillis(millis) +"millis";
        
        
    }
    
    public static String differenceBetweenDate(long start) {
        return differenceBetweenDate( start, System.currentTimeMillis());
    }
    
    public static String differenceBetweenDate(long start, long finish) {
        long millis = finish -start;
    
        
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis)- (TimeUnit.MILLISECONDS.toMinutes(millis)*60);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis) - (TimeUnit.MILLISECONDS.toHours(millis)*60);
        long hours = TimeUnit.MILLISECONDS.toHours(millis) - (TimeUnit.MILLISECONDS.toHours(millis)*24);
        
        
        
        return TimeUnit.MILLISECONDS.toDays(millis) +  " days " 
               + hours +"h "
               + minutes +"m "
               + seconds +"s "
               + TimeUnit.MILLISECONDS.toMillis(millis) +"millis";
        
        
    }
    

    public static Calendar setLastMinuteOfTheDay(Calendar cal) {
        String convertToString = convertToString(cal.getTime(), GIORNOMESEANNO);
        Date data = convertToDate("23:59:59 " + convertToString, ORAMINUTISECONDIGIORNOMESEANNO);
        Calendar cale = Calendar.getInstance();
        cale.setTime(data);
        return cale;
    }

    public static Date convertToDate(String date, String format) {
        Date exit = null;
        try {
            exit = new SimpleDateFormat(format).parse(date);
        } catch (ParseException ex) {
//            Logger.getLogger(DateUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
        return exit;
    }

    public static Date getMinDate(List<Date> mydates) {
        Date exit = null;
        if (mydates != null) {
            if (!mydates.isEmpty()) {
                Collections.sort(mydates, new Comparator<Date>() {

                    @Override
                    public int compare(Date o1, Date o2) {
                        return o1.compareTo(o2);
                    }

                });
                exit = mydates.get(0);
            }
        }

        return exit;
    }

    public static Date getMaxDate(List<Date> mydates) {
        Date exit = null;
        if (mydates != null) {
            if (!mydates.isEmpty()) {
                Collections.sort(mydates, new Comparator<Date>() {

                    @Override
                    public int compare(Date o1, Date o2) {
                        return o1.compareTo(o2);
                    }

                });
                exit = mydates.get(mydates.size() - 1);
            }
        }

        return exit;
    }

    public static Integer differenceInMonths(Date beginningDate, Date endingDate) {
        if (beginningDate == null || endingDate == null) {
            return 0;
        }
        Calendar cal1 = new GregorianCalendar();
        cal1.setTime(beginningDate);
        Calendar cal2 = new GregorianCalendar();
        cal2.setTime(endingDate);
        return differenceInMonths(cal1, cal2);
    }

    public static String fromMillisecToString(long millis) {
        return String.format("%02d min, %02d sec",
                TimeUnit.MILLISECONDS.toMinutes(millis),
                TimeUnit.MILLISECONDS.toSeconds(millis)
                - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis))
        );
    }

    private static Integer differenceInMonths(Calendar beginningDate, Calendar endingDate) {
        if (beginningDate == null || endingDate == null) {
            return 0;
        }
        int m1 = beginningDate.get(Calendar.YEAR) * 12 + beginningDate.get(Calendar.MONTH);
        int m2 = endingDate.get(Calendar.YEAR) * 12 + endingDate.get(Calendar.MONTH);
        return m2 - m1;
    }

//    public static Integer differenceInMonth(Calendar beginningDate, Calendar endingDate) {
//
//        DateTime startDate = new DateTime(beginningDate.getTime());
//        DateTime endDate = new DateTime(endingDate.getTime());
//        int m = Months.monthsBetween(startDate.withDayOfMonth(1), endDate.withDayOfMonth(1)).getMonths();
//        return m;
//
//    }
    public static Integer differenceInMonth(Calendar beginningDate, Calendar endingDate) {
        int exit = 0;
        int bmonth = beginningDate.get(Calendar.MONTH);
        int byear = beginningDate.get(Calendar.YEAR);
        int emonth = endingDate.get(Calendar.MONTH);
        int eyear = endingDate.get(Calendar.YEAR);

        if (byear == eyear) {
            for (int i = bmonth; i < emonth; i++) {
                exit++;
            }
        } else {
            boolean isFirstYear = true;
            for (int i = byear; i <= eyear; i++) {
                if (i == eyear) {
                    Logs.util(TAG, "-|> Stesso ANNO ");
                    for (int b = 0; b < emonth; b++) {
                        exit++;
                    }

                } else if (isFirstYear) {
                    Logs.util(TAG, "-|> Primo ANNO ");
                    for (int c = bmonth; c < 12; c++) {
                        exit++;
                    }

                    isFirstYear = false;
                } else {
                    Logs.util(TAG, "-|> ANNO INTERMEDIO ");
                    for (int a = 0; a < 12; a++) {
                        exit++;
                    }
                }

            }
        }

        return exit;
    }

//    public static List<String> mothBetweenDate(Calendar fromDate, Calendar toDate) {
//
//        List<String> exit = new ArrayList<>();
////        int m = differenceInMonth(beginningDate, endingDate);
//        DateTime startDate = new DateTime(fromDate.getTime());
////        Logs.util(TAG, "DIFFERENZA TRA  : " + convertToString(beginningDate.getTime(), GIORNOMESEANNO) + " | " + convertToString(endingDate.getTime(), GIORNOMESEANNO));
////        Logs.util(TAG, "TROVATO DIFFERENZA DI  : " + m + " mesi" );
//        int initialMonth = startDate.getMonthOfYear();
//        int initialYear = startDate.getYear();
//
//        int m = differenceInMonth(fromDate, toDate);
//        Logs.util(TAG, "*MESI -> " + m);
//        int temp = initialMonth;
//        int count = 1;
//        for (int i = 0; i <= m; i++) {
//            String stringa = Util.numberFormatter(temp) + "-" + initialYear;
//            exit.add(stringa);
//            if ((initialMonth + i) >= (12 * count)) {
//                initialYear++;
//                count++;
//                temp = 1;
//            } else {
//                temp++;
//            }
//
//        }
//        Logs.util(TAG, "----------------------------------------");
//        for (String s : exit) {
//            Logs.util(TAG, s);
//        }
//        Logs.util(TAG, "----------------------------------------");
//        return exit;
//
//    }

    public static boolean isBetweenInterval(Calendar toTest, Calendar start, Calendar end, boolean equals) {
        boolean exit = false;
        if (equals) {
            if (toTest.after(start) && toTest.before(end)) {
                exit = true;
            }
        } else if ((toTest.after(start) || toTest.equals(start)) && (toTest.before(end) || toTest.equals(end))) {
            exit = true;
        }
        return exit;
    }

    public static boolean isBetweenInterval(Date toTest, Date start, Date end, boolean equals) {
        boolean exit = false;
        if (equals) {
            if (toTest.after(start) && toTest.before(end)) {
                exit = true;
            }
        } else if ((toTest.after(start) || toTest.equals(start)) && (toTest.before(end) || toTest.equals(end))) {
            exit = true;
        }
        return exit;
    }

}
