/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lf.cnr.util;

import cnr.lf.lflog.Loggator;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Luca
 */
public class Logs {

    public static void domain(String className, String what) {
        
        Loggator log = Loggator.getInstance();
        log.domain(className, what);
//        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.DOMAIN_DEBUGMODE))) {
//            System.out.println("[D][" + className + "] -> " + what);
//        }
    }

    public static void jpa(String className, String what) {
        Loggator log = Loggator.getInstance();
        log.domain(className, what);
//        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.JPA_DEBUGMODE))) {
//            System.out.println("[J][" + className + "] -> " + what);
//        }
    }

    public static void vaadin(String className, String what) {
        Loggator log = Loggator.getInstance();
        log.domain(className, what);
//        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.JPA_DEBUGMODE))) {
//            System.out.println("[V][" + className + "] -> " + what);
//        }
    }
    public static void util(String className, String what) {
        Loggator log = Loggator.getInstance();
        log.domain(className, what);
//        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.UTIL_DEBUGMODE))) {
//            System.out.println("[U][" + className + "] -> " + what);
//        }
    }

    public static void application(String className, String what) {
        
        Loggator log = Loggator.getInstance();
        log.domain(className, what);
//        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.APPLICATION_DEBUGMODE))) {
//            System.out.println("[A][" + className + "] -> " + what);
//        }
    }
   
    
    public static void testJunit(boolean si,String methodName, String what) {
        if (si) {
            System.out.println("[T][" + methodName + "] -> " + what);
        }
    }
    public static void servlet(boolean si,String methodName, String what) {
        if (si) {
            System.out.println("[S][" + methodName + "] -> " + what);
        }
    }

    public static void lineStart(String className, String methodName) {
        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.DOMAIN_DEBUGMODE))) {
            System.out.println("-START------------------------------------------------------------------------");
            System.out.println("[" + className + "] : " + methodName);
            System.out.println("-+----------------------------------------------------------------------------");
        }
    }

    public static void lineEnd(String className, String methodName) {
        if (Boolean.parseBoolean(Configure.getInstance().getProperty(Configure.DOMAIN_DEBUGMODE))) {
            System.out.println("----------------------------------------------------------------------------");
            System.out.println("[" + className + "] : " + methodName);
            System.out.println("-END------------------------------------------------------------------------");
        }
    }
    
    public static void file(String filename, String className,String toWrite) {
        FileWriter writer;
        try {
            writer = new FileWriter(filename,true);

            
            writer.write("[" + className + "] -> " + toWrite + "\n");

           writer.flush();
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Logs.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    

}
