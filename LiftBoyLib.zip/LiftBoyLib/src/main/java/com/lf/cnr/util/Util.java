/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lf.cnr.util;
 
import com.google.common.collect.ImmutableList;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author Luca Frigerio
 */
public class Util {
    
    
    public static final String DOUBLE_DECIMAL = "#.######";
    public static final String TRIPLE_DECIMAL = "###,###.###";

    private final List<String> lista;
    
    public Util(final List<String> lista) {
        this.lista = lista;
    }
    
    
    public static ImmutableList<String> getNames(Class<? extends Enum<?>> e) {
        return ImmutableList.copyOf(Arrays.stream(e.getEnumConstants()).map(Enum::name).toArray(String[]::new));
    }
    
    
    
    
    
    
    private static final NumberFormat formatter = new DecimalFormat("###,###.##");     
//    private static final NumberFormat formatter = new DecimalFormat("#0.00");     
    
    public void test () {
        for (int i = 0; i < 10; i++) {
            lista.add(UUID.randomUUID().toString());
        }
    }
    
    
    public static List<String> fromTwitterStringToList(String twitters) {
        
        twitters =twitters.replace("(", "");
        twitters =twitters.replace(")", "");
        String[] robba = twitters.split(",");
        List<String> exit = Arrays.asList(robba);
        return exit; 
    }

    public static boolean isNullOrEmpty(String toveryfy) {
        boolean exit = true;
        if (toveryfy != null) {
            if (!toveryfy.isEmpty()) {
                exit = false;
            }
        }
        return exit;
    }

    public static String formatDouble(Double value) {
        return formatter.format(value);
    }
    public static String formatDouble(Double value,String formatting) {
        NumberFormat formatter2 = new DecimalFormat(formatting);
        return formatter2.format(value);
    }
    
    public static String numberCoerence(String value) {
        if (value != null) {
            if ( !value.isEmpty() ) {
                return value;
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }
    
  

    public static boolean isNullOrEmpty(List<String> toveryfy) {
        boolean exit = true;
        if (toveryfy != null) {
            if (toveryfy.size() > 0) {
                exit = false;
            }
        }
        return exit;
    }
    
    public static String numberFormatter(int number) {
        String exit = "";
        if (number <10) {
            exit = "0" + number;
        } else {
            exit = ""+number;
        }
        return exit;
    }
    
  
}
