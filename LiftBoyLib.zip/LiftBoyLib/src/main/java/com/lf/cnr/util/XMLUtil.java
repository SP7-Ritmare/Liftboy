/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lf.cnr.util;

import com.google.common.collect.Sets;
import java.io.File;
import java.io.FileInputStream;
import java.util.Set;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
/**
 *
 * @author Luca Frigerio
 */
public class XMLUtil {

    public static Set<String> getPrefix(String filename) throws Exception {

        Set<String> exit = Sets.newHashSet();
        File file = new File(filename);

        if (!file.exists()) {
            throw new Exception("Prefix : File does not exist");
        }
        
        XMLInputFactory inputFactory = XMLInputFactory.newInstance();
        XMLStreamReader reader = inputFactory.createXMLStreamReader(new FileInputStream(file));
        
        while (reader.hasNext()) {
            int evt = reader.next();
            if (evt == XMLStreamConstants.START_ELEMENT) {
                int counter = reader.getAttributeCount();
                for (int i = 0; i < counter; i++) {
                    String x = reader.getAttributePrefix(i);
                    if (x != null) {
                        exit.add(x);
                    }
                }
            }
        }
        int count = 1;
        System.out.println("+ NAME SPACES FOUND ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        for (String namespace : exit) {
            System.out.println("-- Name Spaces ("+ count +") : " + namespace);
           
         
            count++;
        }
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        return exit;

    }
    
    public static Set<String> stringsToFind (Set<String> prefix, String paremeter) {
        Set<String> exit = Sets.newHashSet(paremeter);
        if (prefix != null) {
            if (!prefix.isEmpty()) {
                prefix.forEach((temp) -> {
                    exit.add(temp+":"+paremeter);
                });
            }
        }
        return exit;
    }
    
    public static String verifyIfThePathIsAbsoluteAndReturnTheRightValue(String hasroot, String haspath) {
        if (haspath.contains(hasroot)) {
            return haspath;
        } else {
            int lunghezza_hasroot = hasroot.length();
//            if ( hasroot.charAt(lunghezza_hasroot-1) == "/".charAt(0) ) {
                return hasroot+"/"+haspath;
//            } else {
//                return hasroot+haspath;
//            }
            
            
        }
    }
    

}
