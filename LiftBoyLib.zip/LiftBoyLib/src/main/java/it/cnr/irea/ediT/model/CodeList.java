/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

import com.google.common.collect.Sets;
import com.lf.cnr.util.Util;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Objects;
import java.util.Set;

/**
 *
 * @author Luca Frigerio
 */
public class CodeList {

    private final String id;
    private final EndPointType endpointType;
    private final String uri;
    private final String url;

    public static String DEFAULT_URL = "http://sparql.get-it.it";

    private final String PARAMETER = "\\$search_param";

    public static String CODELISTQUERY = "        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
            + "        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>"
            + "        SELECT ?c ?l ?a ?b"
            + "        WHERE {"
            + "          ?c rdf:type skos:Concept ."
            + "          OPTIONAL {"
            + "            ?c skos:prefLabel ?x ."
            //            + "            FILTER( LANG(?l) = \"en\")"
            + "          }"
            + "          {"
            + "            ?c skos:prefLabel ?l ."
            + "            FILTER( LANG(?l) = \"en\")"
            + "          }"
            + "          OPTIONAL {"
            + "            ?c skos:prefLabel ?a ."
            + "            FILTER( LANG(?a) = \"it\")"
            + "          }"
            + "          OPTIONAL {"
            + "            ?c skos:prefLabel ?b ."
            + "            FILTER( LANG(?b) = \"zxx\")"
            + "          }"
            + "          FILTER( REGEX( STR(?x), \"$search_param\", \"i\") )"
            + "        }"
            //            + "        ORDER BY ASC(?l)  ";
            //            + "        ORDER by fn:string-length(STR(?x)) limit 1";
            + "        ORDER by fn:string-length(STR(?x)) limit 10";

    public CodeList(String id, EndPointType endPoint, String uri, String url) {
        this.id = id;
        this.endpointType = endPoint;
        this.uri = uri;
        this.url = url;
    }

    public String getId() {
        return id;
    }

    public static void setCODELISTQUERY(String CODELISTQUERY) {
        if (!Util.isNullOrEmpty(CODELISTQUERY)) {
            CodeList.CODELISTQUERY = CODELISTQUERY;
        }

    }

    public static void setDEFAULT_URL(String DEFAULT_URL) {
        if (!Util.isNullOrEmpty(DEFAULT_URL)) {
            CodeList.DEFAULT_URL = DEFAULT_URL;
        }
    }

    public EndPointType getEndPoint() {
        return endpointType;
    }

    public String getUri() {
        return uri;
    }

    public String getUrl() {
        return url;
    }

    public String getCompleteQueryCodelist(String value) {
        return CODELISTQUERY.replaceAll(PARAMETER, value);
    }

    public String getUrlSegment(String value) throws UnsupportedEncodingException {

        String query = endpointType.getQueryParameter();
//        String endpoint = endpointType.getSparqlEndpoint();

        String endpoint = url;
        if (Util.isNullOrEmpty(endpoint))  {
            endpoint = DEFAULT_URL;
        }
//        String endpoint = "http://sparql.get-it.it";
        String completeQuery = getCompleteQueryCodelist(value);

        String full_query = URLEncoder.encode(completeQuery, "UTF-8");
        String parameters = "";
        for (String key : endpointType.getParameters().keySet()) {
            parameters = parameters + key + endpointType.getParameters().get(key) + "&";
        }

        return endpoint + "?" + query + "=" + full_query + "&" + parameters;

    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CodeList other = (CodeList) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "CodeList{" + "id=" + id + ", endPoint=" + endpointType + ", uri=" + uri + ", url=" + url + '}';
    }

}
