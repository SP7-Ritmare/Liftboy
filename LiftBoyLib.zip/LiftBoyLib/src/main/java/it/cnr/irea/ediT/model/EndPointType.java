/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

import com.google.common.collect.Maps;
import com.lf.cnr.util.Util;
import java.util.Map;
import java.util.Objects;

/**
 *
 * @author Luca Frigerio
 */
public class EndPointType {
    
    private final String id;
    private String method;
    private String queryParameter;
    private String sparqlEndpoint;
    
   
    
    
    private final Map<String,String> parameters;

    public EndPointType(String id) throws Exception {
        this.id = id;
        parameters = Maps.newHashMap();
        
        validate();
    }
    
    private void validate() throws Exception {
        if (Util.isNullOrEmpty(id)) {
            throw new Exception("PreQuery Id is null on creation");
        }
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getQueryParameter() {
        return queryParameter;
    }

    public void setQueryParameter(String queryParameter) {
        this.queryParameter = queryParameter;
    }

    public String getSparqlEndpoint() {
        return sparqlEndpoint;
    }

    public void setSparqlEndpoint(String sparqlEndpoint) {
        this.sparqlEndpoint = sparqlEndpoint;
    }
    
    
    public void addParameter(String key, String value) throws Exception {
        if (Util.isNullOrEmpty(value) || Util.isNullOrEmpty(key)) {
            throw new Exception("PARAMETER : ONE OF THE VALUE IS NULL");
        } else {
            parameters.put(key, value);
        }
    }

    public String getId() {
        return id;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EndPointType other = (EndPointType) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EndPointType{" + "id=" + id + ", method=" + method + ", queryParameter=" + queryParameter + ", sparqlEndpoint=" + sparqlEndpoint + ", parameters=" + parameters + '}';
    }

   
    
}
