/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

import java.util.Objects;

/**
 *
 * @author Luca Frigerio
 */
public class PosizioneEValore {
    
    
    private  Integer posizione;
    private  PreTemplateItem preTemplateItem;

    public PosizioneEValore(Integer posizione, PreTemplateItem preTemplateItem) {
        this.posizione = posizione;
        this.preTemplateItem = preTemplateItem;
    }

    public Integer getPosizione() {
        return posizione;
    }

    public PreTemplateItem getPreTemplateItem() {
        return preTemplateItem;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.posizione);
        hash = 97 * hash + Objects.hashCode(this.preTemplateItem);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PosizioneEValore other = (PosizioneEValore) obj;
        if (!Objects.equals(this.posizione, other.posizione)) {
            return false;
        }
        if (!Objects.equals(this.preTemplateItem, other.preTemplateItem)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "PosizioneEValore{" + "posizione=" + posizione + ", preTemplateItem=" + preTemplateItem + '}';
    }
    
    
    
   
    

    
    
    
}
