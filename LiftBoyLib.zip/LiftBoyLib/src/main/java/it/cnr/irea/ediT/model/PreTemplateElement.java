/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;


/**
 *
 * @author Luca Frigerio
 */
public class PreTemplateElement extends TemplateElement {

    public final static String TOSUBSTITUTE = "$search_param";
    private EndPointType preQuery;
    private boolean isMultiple;

    public PreTemplateElement( String id) throws Exception {
        super(id);
        
    }

    public EndPointType getPreQuery() {
        return preQuery;
    }

    public void setPreQuery(EndPointType preQuery) {
        this.preQuery = preQuery;
    }

    public boolean isIsMultiple() {
        return isMultiple;
    }

    public void setIsMultiple(boolean isMultiple) {
        this.isMultiple = isMultiple;
    }

   
   
    

}
