/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.lf.cnr.util.Logs;
import com.lf.cnr.util.SetList;
import com.lf.cnr.util.Util;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Luca Frigerio
 */
public class PreTemplateItem extends TemplateItem {
    
    private String TAG= "PreTemplateItem";

//    private String toSearch;
    private Sparql sparql;
    private CodeList codeList;

    // if we found multiple values in the iso file.
    private List<String> multiple_values;

    private List<String> multiple_to_search;

    private Map<String, SetList<String>> multiple_codevalue;

    public PreTemplateItem(String id) throws Exception {
        super(id);
    }

    public int sizeOfMultipleValues() {
        if (multiple_values != null) {
            return multiple_values.size();
        } else {
            return 0;
        }
    }

    public boolean hasMultipleValuesForTheQueries(String tosearch) {
        if (multiple_codevalue != null) {
            if (multiple_codevalue.get(tosearch) != null) {
                return !multiple_codevalue.get(tosearch).isEmpty();
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    public String getToSearch(int pos) {
        return multiple_to_search.get(pos);
    }
//    public String getCodeValue(String key) {
//        return multiple_codevalue.get(key);
//    }

    public void addToSearch(String toSearch) {
        if (!Util.isNullOrEmpty(toSearch)) {
            if (this.multiple_to_search == null) {
                this.multiple_codevalue = Maps.newHashMap();
                this.multiple_to_search = Lists.newArrayList();
            }
            this.multiple_to_search.add(toSearch);
        }

    }

    public int multiple_to_search_size() {
        if (this.multiple_to_search == null) {
            return 0;
        } else {
            return this.multiple_to_search.size();
        }
    }

    public Sparql getSparql() {
        return sparql;
    }

    public void setSparql(Sparql sparql) {
        this.sparql = sparql;
    }

    public CodeList getCodeList() {
        return codeList;
    }

    public void setCodeList(CodeList codeList) {
        this.codeList = codeList;
    }

    public boolean isMultipleValue() {
        boolean exit = false;
        if (!Util.isNullOrEmpty(super.getValue())) {
            if (multiple_values.size() > 1) {
                exit = true;
            }
        }
        return exit;
    }

    @Override
    public void setValue(String value) {

        if (Util.isNullOrEmpty(super.getValue())) {
            super.setValue(value);
            multiple_values = Lists.newArrayList();
            multiple_values.add(value);

        } else {
            multiple_values.add(value);
        }
        //To change body of generated methods, choose Tools | Templates.
    }

    public void addCodeValue(String key, String codeValue) {
        if (multiple_codevalue == null) {
            multiple_codevalue = Maps.newHashMap();
        }
        if (multiple_codevalue.containsKey(key)) {
            SetList<String> values = multiple_codevalue.get(key);
            values.add(codeValue);
            multiple_codevalue.put(key, values);
        } else {
            SetList<String> values = new SetList();
            values.add(codeValue);
            multiple_codevalue.put(key, values);
        }

    }

    public String getFirstCodeValue(String key) {
        if (multiple_codevalue != null) {
            System.out.println("-----------------------------");
            System.out.println("E' DIVERSO DA NULL");
            if (multiple_codevalue.get(key) == null) {
                System.out.println("IL SET E' NULL");
            } else {
                System.out.println("IL SET E' " + multiple_codevalue.get(key).size());
            }
            System.out.println("-----------------------------");
        }
        return multiple_codevalue.get(key).get(0);

    }

    public List<String> getMultiple_to_search() {
        return multiple_to_search;
    }

    public Map<String, SetList<String>> getMultiple_codevalue() {
        return multiple_codevalue;
    }

    public int sizeOfMultipleValue(String key) {
        if (multiple_to_search != null) {
            return multiple_codevalue.get(key).size();
        } else {
            System.out.println("BUT IS NULL");
            return 0;
        }
    }

    public String getUrlToSearch(int pos) throws UnsupportedEncodingException {

        if (isToSearch()) {
            if (isAutocompletion()) {
                return sparql.getUrlSegment(multiple_to_search.get(pos));
            } else if (isCodelist()) {
                return codeList.getUrlSegment(multiple_to_search.get(pos));
            }

        }
        
        return "";

    }

    public List<String> getMultiple_values() {
        return multiple_values;
    }

    public boolean isToSearch() {
        boolean exit = false;
        
//        Logs.application(TAG,"IS AUTOCOMPLETE ? : " + this.getDatatype().equals(DataType.autoCompletion.toString()));
//        Logs.application(TAG,"IS CODELIST ? : " + this.getDatatype().equals(DataType.codelist.toString()));
//        Logs.application(TAG,"IS IS MULTIPLETOSEARCH NOT NULL ? : " + !Util.isNullOrEmpty(multiple_to_search));
        if ((this.getDatatype().equals(DataType.autoCompletion.toString()) || this.getDatatype().equals(DataType.codelist.toString())) && !Util.isNullOrEmpty(multiple_to_search)) {
//        if (this.getDataType().equals(DataType.autoCompletion.toString())) {
            exit = true;
        }
        return exit;
    }

    public boolean isAutocompletion() {
        boolean exit = false;
//        if (this.getDataType().equals(DataType.autoCompletion.toString()) || this.getDataType().equals(DataType.codelist.toString()) ) {
        if (this.getDatatype().equals(DataType.autoCompletion.toString())) {
            exit = true;
        }
        return exit;
    }

    public boolean isCodelist() {
        boolean exit = false;
//        if (this.getDataType().equals(DataType.autoCompletion.toString()) || ) {
        if (this.getDatatype().equals(DataType.codelist.toString())) {
            exit = true;
        }
        return exit;
    }

    @Override
    public String toString() {
        return "PreTemplateItem{" + "sparql=" + sparql + ", codeList=" + codeList + ", multiple_values=" + multiple_values + ", multiple_to_search=" + multiple_to_search + '}';
    }

}
