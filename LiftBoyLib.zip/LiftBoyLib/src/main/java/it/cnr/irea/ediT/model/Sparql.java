/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

import com.lf.cnr.util.Util;
import static it.cnr.irea.ediT.model.CodeList.DEFAULT_URL;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Objects;

/**
 *
 * @author Luca Frigerio
 */
public class Sparql {

    private final String id;
    private final EndPointType endpointType;
    private final String query;
    public static String DEFAULT_URL = "http://sparql.get-it.it";
    private final String PARAMETER = "\\$search_param";

    public Sparql(String id, EndPointType endpointType, String query) {
        this.id = id;
        this.endpointType = endpointType;
        this.query = query;
    }

    public String getId() {
        return id;
    }

    public EndPointType getEndpointType() {
        return endpointType;
    }

    public String getQuery() {
        return query;
    }

    public String getCompleteQueryAutoCompletion(String value) {
        return query.replaceAll(PARAMETER, value);
    }
    public static void setDEFAULT_URL(String DEFAULT_URL) {
        if (!Util.isNullOrEmpty(DEFAULT_URL)) {
            CodeList.DEFAULT_URL = DEFAULT_URL;
        }
    }

    public String getUrlSegment(String value) throws UnsupportedEncodingException {
        String query = endpointType.getQueryParameter();
//        String endpoint = endpointType.getSparqlEndpoint();
        
        String endpoint =  endpointType.getSparqlEndpoint();
        if (Util.isNullOrEmpty(endpoint))  {
            endpoint = DEFAULT_URL;
        }
//        String endpoint = "http://sparql.get-it.it";
        String completeQuery = getCompleteQueryAutoCompletion(value);
        

        String full_query = URLEncoder.encode(completeQuery, "UTF-8");
        String parameters = "";
        for (String key : endpointType.getParameters().keySet()) {
            parameters = parameters + key + endpointType.getParameters().get(key) + "&";
        }

        return endpoint + "?" + query + "=" + full_query + "&" + parameters;

    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 31 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sparql other = (Sparql) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Sparql{" + "id=" + id + ", endpointType=" + endpointType + ", query=" + query + '}';
    }

}
