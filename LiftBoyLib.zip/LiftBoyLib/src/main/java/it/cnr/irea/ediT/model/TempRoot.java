/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import java.util.List;

/**
 *
 * @author Luca Frigerio
 */
@JacksonXmlRootElement(localName = "elements")
public class TempRoot {
    
    
    private final String version;
    private final String template;
    private final String fileId;
    private final String fileUri;

    private final List<TemplateElement> element;

//    public TempRoot(List<TemplateElement> element, ) {
//        this.element = element;
//    }

    public TempRoot(String version, String template, String fileId, String fileUri, List<TemplateElement> element) {
        this.version = version;
        this.template = template;
        this.fileId = fileId;
        this.fileUri = fileUri;
        this.element = element;
    }

    public String getVersion() {
        return version;
    }

    public String getTemplate() {
        return template;
    }

    public String getFileId() {
        return fileId;
    }

    public String getFileUri() {
        return fileUri;
    }
    
    

//    @JacksonXmlElementWrapper(localName = "aaaa")
    @JacksonXmlProperty(localName = "element")
    public List<TemplateElement> getElement() {
        return element;
    }

}
