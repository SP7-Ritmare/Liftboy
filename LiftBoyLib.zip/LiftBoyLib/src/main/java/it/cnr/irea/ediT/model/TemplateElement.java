/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

/**
 *
 * @author Luca Frigerio
 */
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.google.common.collect.Lists;
import com.lf.cnr.util.SetList;
import com.lf.cnr.util.Util;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

public class TemplateElement {

    private String id;
    private String root;
    private String mandatory;
    private String label;
    private String represents_element;
    
    private SetList<TemplateItem> items;

    public TemplateElement(String id) throws Exception {
        this.id = id;
        validate();
    }

    private void validate() throws Exception {

        if (Util.isNullOrEmpty(id)) {
            throw new Exception("TemplateElement : Id is null");

        }

    }

    public String getId() {
        return id;
    }

    public String getRoot() {
        if (root == null || root.equalsIgnoreCase("NA")) {
            return null;
        }
        return root;
    }

    public void setRoot(String root) {
        this.root = root;
    }

    public String getMandatory() {
        return mandatory;
    }

    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @JacksonXmlElementWrapper(localName = "items")
    @JacksonXmlProperty(localName = "item")
    public List<TemplateItem> getItems() {
        return items;
    }

    public void setItems(SetList<TemplateItem> items) {
        this.items = items;
    }

    public void addItem(TemplateItem item) {
        if (items == null) {
            items = new SetList<>();
//            items = Lists.newArrayList();
        }
        item.setElement_Id(id);
        items.add(item);

    }
    
    public void addCollection(Collection<TemplateItem> items_toAdd) {
        if (items == null) {
            items = new SetList<>();
//            items = Lists.newArrayList();
        }
        for(TemplateItem ti : items_toAdd) {
           ti.setElement_Id(id);
           items.add(ti);
        }
        
        

    }
    

    public String getRepresents_element() {
        return represents_element;
    }

    public void setRepresents_element(String represents_element) {
        this.represents_element = represents_element;
    }
    
    

    @Override
    public String toString() {
        return "TemplateElement [id=" + id + ", root=" + root + ", mandatory="
                + mandatory + ", label=" + label + ", items=" + items + "]";
    }
    
    

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TemplateElement other = (TemplateElement) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

}
