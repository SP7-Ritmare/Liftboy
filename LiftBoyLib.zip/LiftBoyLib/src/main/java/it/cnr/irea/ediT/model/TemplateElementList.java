/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

/**
 *
 * @author Luca Frigerio
 */
import java.net.URI;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.collect.Lists;
import java.io.Serializable;
import java.util.Objects; 
import javax.xml.bind.annotation.XmlElementWrapper;

@XmlRootElement(name = "elements")
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"generator", "ediVersion", "version", "timestamp", "baseDocument", "xsltChain", "numElements", "templateName", "templateDocument", "fileId", "fileUri", "user", "queryString", "elements", "starterKit", "starterKitUri"})
@JsonPropertyOrder({
    "generator",
    "ediVersion",
    "starterKit",
    "starterKitUri",
    "timestamp",
    "baseDocument",
    "xsltChain",
    "templateName",
    "templateDocument",
    "version",
    "fileId",
    "fileUri",
    "user",
    "queryString",
    "numElements",
    "elements"
})
public class TemplateElementList implements Serializable {

    private List<TemplateElement> elements;
    private Date timestamp = new Date();
    private String queryString;
    private String templateName;
    private String templateDocument;
    private String fileId;
    private URI fileUri;
    private String user;
    private String version;
    private String starterKit;
    private String starterKitUri;
    private String baseDocument;
    private List<XsltUrl> xsltChain;
    private String ediVersion;
    
     public void addElement(TemplateElement element) {
        if (elements == null) {
            elements = Lists.newArrayList();
        }
//        element.setElementId(id);
        elements.add(element);
    
    }
    

    public TemplateElement findElement(String id) {
        for (TemplateElement element : elements) {
            if (element.getId().equalsIgnoreCase(id)) {
                return element;
            }
        }
        return null;
    }

    public TemplateItem findItem(String elementId, String itemId) {
        TemplateElement element = findElement(elementId);
        if (element != null) {
            for (TemplateItem item : element.getItems()) {
                if (item.getId().equalsIgnoreCase(elementId + "_" + itemId)) {
                    return item;
                }
            }
        }
        return null;
    }

    public TemplateElementList() {
    }
    
    
    

    public String getStarterKit() {
        return starterKit;
    }

    public void setStarterKit(String starterKit) {
        this.starterKit = starterKit;
    }

    public String getEdiVersion() {
        return ediVersion;
    }

    public void setEdiVersion(String ediVersion) {
        this.ediVersion = ediVersion;
    }

    public URI getFileUri() {
        return fileUri;
    }

    public void setFileUri(URI fileUri) {
        this.fileUri = fileUri;
    }

    @XmlElement(name = "version", defaultValue = "1.00")
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getBaseDocument() {
        return baseDocument;
    }

    public void setBaseDocument(String baseDocument) {
        this.baseDocument = baseDocument;
    }

    @XmlElement(name = "template")
    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    @XmlElement(name = "fileId")
    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    @XmlElement(name = "user")
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    @XmlElement(name = "querystring")
    public String getQueryString() {
        return queryString;
    }

    public void setQueryString(String queryString) {
        this.queryString = queryString;
    }
    @XmlElementWrapper(name = "elements")
    @XmlElement(name = "element")
    public List<TemplateElement> getElements() {
        return elements;
    }

    public void setElements(List<TemplateElement> elements) {
        this.elements = elements;
    }

    @XmlElement(name = "timestamp")
    public Date getTimestamp() {
        return timestamp;
    }

    @XmlElement(name = "num_elements")
    public int getNumElements() {
        if (elements == null) {
            return 0;
        } else {
            return elements.size();
        }
    }

    @XmlElement(name = "generator")
    public String getGenerator() {
        return "RITMARE EDI_NG Server";
    }

    public String getStarterKitUri() {
        return starterKitUri;
    }

    public void setStarterKitUri(String starterKitUri) {
        this.starterKitUri = starterKitUri;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public List<XsltUrl> getXsltChain() {
        return xsltChain;
    }

    public void setXsltChain(List<XsltUrl> xsltChain) {
        this.xsltChain = xsltChain;
    }

    @XmlElement(name = "templateDocument")
    public String getTemplateDocument() {
        return templateDocument;
    }

    public void setTemplateDocument(String templateDocument) {
        this.templateDocument = templateDocument;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.fileId);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TemplateElementList other = (TemplateElementList) obj;
        if (!Objects.equals(this.fileId, other.fileId)) {
            return false;
        }
        return true;
    }
    
    
    

}
