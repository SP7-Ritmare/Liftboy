/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.cnr.irea.ediT.model;

/**
 *
 * @author Luca Frigerio
 */
import com.lf.cnr.util.Util;
import java.util.Objects;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = {"id", "elementId", "path", "datatype", "fixed", "useCode", "outIndex", "value", "labelValue", "codeValue", "urnValue", "languageNeutral", "listeningFor", "isLanguageNeutral", "datasource", "hasIndex", "field", "show", "defaultValue", "query"})
public class TemplateItem {

    private String id;
    private String element_Id;
    private String path;
    private String datatype;
    private String fixed;
    private String useCode;
    private String useURN;
    private String outIndex;
    private String value;
    private String labelValue;
    private String codeValue;
    private String urnValue;
    private String languageNeutral;
    private String listeningFor;
    private String isLanguageNeutral;
    private String datasource;
    private String hasIndex;
    private String field;
    private String itemId;
    private String show;
    private String defaultValue;
    private String query;

    public TemplateItem(String id) throws Exception {
        this.id = id;
        validate();
    }

    private void validate() throws Exception {

        if (Util.isNullOrEmpty(id)) {
            throw new Exception("TemplateElement : Id is null");

        }

    }

    public String getUrnValue() {
        return urnValue;
    }

    public void setUrnValue(String urnValue) {
        this.urnValue = urnValue;
    }

    public String getUseCode() {
        return useCode;
    }

    public void setUseCode(String useCode) {
        this.useCode = useCode;
    }

    public String getUseURN() {
        return useURN;
    }

    public void setUseURN(String useURN) {
        this.useURN = useURN;
    }

    public String getOutIndex() {
        return outIndex;
    }

    public void setOutIndex(String outIndex) {
        this.outIndex = outIndex;
    }

    public String getCodeValue() {
        return codeValue;
    }

    public void setCodeValue(String codeValue) {
        this.codeValue = codeValue;
    }

   
    public String getDatatype() {
        return datatype;
    }

    public void setDatatype(String dataType) {
        this.datatype = dataType;
    }

    public String getFixed() {
        return fixed;
    }

    public void setFixed(String fixed) {
        this.fixed = fixed;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

  
    public String getElement_Id() {
        return element_Id;
    }

    public void setElement_Id(String elementId) {
        this.element_Id = elementId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDatasource() {
        return datasource;
    }

    public void setDatasource(String datasource) {
        this.datasource = datasource;
    }

    public String getIsLanguageNeutral() {
        return isLanguageNeutral;
    }

    public void setIsLanguageNeutral(String isLanguageNeutral) {
        this.isLanguageNeutral = isLanguageNeutral;
    }

    public String getLanguageNeutral() {
        return languageNeutral;
    }

    public void setLanguageNeutral(String languageNeutral) {
        this.languageNeutral = languageNeutral;
    }

    public void dump() {
        System.out.println(this.toString());
    }

    public String getHasIndex() {
        return hasIndex;
    }

    public void setHasIndex(String hasIndex) {
        this.hasIndex = hasIndex;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getShow() {
        return show;
    }

    public void setShow(String show) {
        this.show = show;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getLabelValue() {
        return labelValue;
    }

    public void setLabelValue(String labelValue) {
        this.labelValue = labelValue;
    }

    public String getListeningFor() {
        return listeningFor;
    }

    public void setListeningFor(String listeningFor) {
        this.listeningFor = listeningFor;
    }
    
    
    

    @Override
    public String toString() {
        return "TemplateItem [id=" + id + ", elementId=" + element_Id
                + ", path=" + path + ", codeValue=" + codeValue + ", urnValue="
                + urnValue + ", value=" + value + ", dataType=" + datatype
                + ", fixed=" + fixed + ", isLanguageNeutral="
                + isLanguageNeutral + ", languageNeutral=" + languageNeutral
                + ", useCode=" + useCode + ", useURN=" + useURN + ", outIndex="
                + outIndex + ", datasource=" + datasource + "]";
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TemplateItem other = (TemplateItem) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

}
