/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import java.io.InputStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Luca Frigerio
 */
public class Test1 {

    public Test1() {

    }
    
    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/";
    private String FILENAME1 = "20131023_patch.rdf";
//    private String PATH = "/home/carnauser/NetBeansProjects/EDI-NG_client/dist/templates/";
//    private String FILENAME1 = "SensorML101_v3.00.xml";

    
//    @Test
    public void test() {
        // create an empty model
//        Model model = ModelFactory.createDefaultModel();
//
//        // use the FileManager to find the input file
//        InputStream in = FileManager.get().open(PATH+ FILENAME1);
//        if (in == null) {
//            throw new IllegalArgumentException(
//                    "File: " + PATH+ FILENAME1 + " not found");
//        }

// read the RDF/XML file
//        model.read(in, null);
//
//// write it to standard out
//        model.write(System.out);
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
