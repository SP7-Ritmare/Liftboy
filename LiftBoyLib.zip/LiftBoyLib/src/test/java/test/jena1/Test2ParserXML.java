/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import java.io.FileInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.w3c.dom.Document;
import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Element;

/**
 *
 * @author Luca Frigerio
 */
public class Test2ParserXML {
    
    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/3/";
    private String FILENAME1 = "RNDT_dataset_v5.00.xml";

    public Test2ParserXML() {
    }

    
    
//    @Test
    public void test() {
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;
        try {
            builder = builderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        try {
            Document document = builder.parse(new FileInputStream(PATH+ FILENAME1));
            
            Element docEle = document.getDocumentElement();
            System.out.println("Root element of the document: "	+ docEle.getNodeName());
            
            
        } catch (SAXException e) {
            e.printStackTrace();
            assertFalse(true);
        } catch (IOException e) {
            e.printStackTrace();
            assertFalse(true);
        }
        
        // TO PARSE A STRING 
//        String xml = ...;
//        Document xmlDocument = builder.parse(new ByteArrayInputStream(xml.getBytes()));


        XPath xPath =  XPathFactory.newInstance().newXPath();


    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
