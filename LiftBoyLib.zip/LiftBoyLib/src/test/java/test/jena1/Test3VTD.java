/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import cnr.lf.template.classes.VtdXmlCurrentState;
import com.ximpleware.AutoPilot;
import com.ximpleware.NavException;
import com.ximpleware.PilotException;
import com.ximpleware.VTDGen;
import com.ximpleware.VTDNav;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Luca Frigerio
 */
public class Test3VTD {

    private String PATH = "/media/carnauser/Volume/CNR/DatiNapoloi/";
    private String PATH2 = "/home/carnauser/Scrivania/cristianoRDFExample/2/";
    private String FILENAME1 = "metadataRNDT.xml";
    private String FILENAME2 = "generated_11576.xml";

    public Test3VTD() {
    }

    @Test
    public void test() {
        List<String> founded = new ArrayList<>();
        try {
            File f = new File(PATH + FILENAME1);
            FileInputStream fis = new FileInputStream(f);
            byte[] ba = new byte[(int) f.length()];
            fis.read(ba);
            VTDGen vg = new VTDGen();
            vg.setDoc(ba);
            vg.parse(false);
            VTDNav vn = vg.getNav();
            AutoPilot ap = new AutoPilot();
            ap.bind(vn);
            ap.selectElementNS("*", "*");
            VtdXmlCurrentState cxp = new VtdXmlCurrentState();
            int count = 0;
            boolean r = true;
            while (r) {
                r = ap.iterate();
                for (String x : cxp.currentXPath(vn)) {
                    System.out.println("[" + count + "] ==>" + x);
                }
                count++;
            }

        } catch (Exception e) {
            System.out.println("exception occurred ==>" + e);
        }

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
