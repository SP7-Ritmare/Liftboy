/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import com.ximpleware.AutoPilot;
import com.ximpleware.EOFException;
import com.ximpleware.EntityException;
import com.ximpleware.NavException;
import com.ximpleware.ParseException;
import com.ximpleware.VTDGen;
import com.ximpleware.VTDNav;
import com.ximpleware.XPathEvalException;
import com.ximpleware.XPathParseException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Luca Frigerio
 */
public class Test4VTD2 {

    public Test4VTD2() {

    }

    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/5/";
    private String PATH2 = "/home/carnauser/Scrivania/cristianoRDFExample/5/";
     private String FILENAME2 = "0.xml";
    private String FILENAME1 = "isoFromThredds_v1.00.xml";
  

    @Test
    public void test() {

        FileInputStream fis2 = null;
        try {
            int count = 0;
            int count2 = 0;
            File f2 = new File(PATH2 + FILENAME2);
            System.out.println(PATH2 + FILENAME2);
            System.out.println("----------------------------------------------------------------------------------------------------");
            fis2 = new FileInputStream(f2);
            byte[] ba2 = new byte[(int) f2.length()];
            fis2.read(ba2);
            VTDGen vg2 = new VTDGen();
            vg2.setDoc(ba2);
            vg2.parse(true);
            VTDNav vn2 = vg2.getNav();
            count = 0;
            AutoPilot ap = new AutoPilot();
            ap.bind(vn2);
            ap.declareXPathNameSpace("gmd", "http://www.isotc211.org/2005/gmd");
            ap.declareXPathNameSpace("gco", "http://www.isotc211.org/2005/gco");
            ap.declareXPathNameSpace("gml", "http://www.opengis.net/gml/3.2");
            ap.declareXPathNameSpace("xlink", "http://www.w3.org/1999/xlink");
//            ap.declareXPathNameSpace("gmd", "http://www.isotc211.org/2005/gmd");
//            ap.declareXPathNameSpace("gco", "http://www.isotc211.org/2005/gco");
//            ap.declareXPathNameSpace("gml", "http://www.opengis.net/gml/3.2");
            //            for (String xpath : founded) {
//                if (!xpath.contains("http") && !xpath.contains("$TODAY$")) {
//                    System.out.println(" xpath ====> " + xpath);
//            ap.selectXPath("//element//item[@hasDatatype=\"codelist\"]");
            int result = -1;
//                    
//            while (ap.evalXPath() != -1) {
//                
//            }
//            System.out.println("---++------------------------------------------------------------------------------------------++-------");
//            while ((result = ap.evalXPath()) != -1) {
//                count++;
////                System.out.println("Element name ==> " + vn2.toString(result) + " : " + vn2.getText() + " | " + vn2.toNormalizedString(vn2.getText()));
////
//            }
//            result = -1;
            ap.selectXPath("/gmd:MD_Metadata/gmd:language/gco:CharacterString");

            while ((result = ap.evalXPath()) != -1) {
                count2++;
//                int a = vn2.getAttrVal("datasource");
                System.out.println(" result ==> [" + result + "] ");
                
                
                if (result != -1) {
                    String value = vn2.toNormalizedString(result);
                    int text = vn2.getAttrVal(vn2.toNormalizedString(result)); 
                    System.out.println("-- NOT TEXT  ==> [" + result + "] " + vn2.getTokenType(result) + "    "+ vn2.toNormalizedString(result));
                    System.out.println("-- TEXT  ==> [" + result + "] "+  vn2.toNormalizedString(text));
                    
                } 
                
//                 int hasroot_pos = vn2.getText();
//                System.out.println(" datasource ==> [" + result + "] " + vn2.toNormalizedString(result));
//                System.out.println(" datasource ==> [" + result + "] " + vn2.toNormalizedString(result) +  " | " +vn2.toString(result));
//                vn2.toElement(VTDNav.FIRST_CHILD, "hasPath");
//                int t = vn2.getText();
//                if (t != -1) //test to see if the element has text node or not 
//                {
//                    System.out.println(" Path ==> [" + t + "] " + vn2.toString(t) + " | ");
//                }
//                vn2.toElement(VTDNav.PARENT);
//
//                vn2.toElement(VTDNav.PARENT);
//                vn2.toElement(VTDNav.PARENT);
//
//                System.out.println(" vn2.getAttrCount() ==> [" + vn2.getAttrCount() + "] ");
//                int x = vn2.getAttrVal("xml:id");
//                System.out.println(" id ==> [" + x + "] ");
//
//                vn2.toElement(VTDNav.FIRST_CHILD, "label");
////                vn2.toElement(VTDNav.PARENT);
//                t = vn2.getText();
//                System.out.println(" Position ==> [" + t + "] ");
//                if (t != -1) //test to see if the element has text node or not 
//                {
//                    System.out.println(" label ==> [" + t + "] " + vn2.toString(t) + " | ");
//                }

//                System.out.println(" Position ID ==> [" + a + "] ");
//                if (t != -1) //test to see if the element has text node or not 
//                {
//                    System.out.println(" id ==> [" + a + "] " + vn2.toNormalizedString(a));
//                }
//                int x = vn2.getText();
//                vn2.toElement(VTDNav.PARENT);
//                t = vn2.getText();
//
////                System.out.println(" Position ==> [" + t + "] ");
//
////                vn2.toElement(VTDNav.PARENT, "element");
//                int id = vn2.getAttrVal("id");
//                System.out.println(" PArent id ==> [" + id + "] " + vn2.toNormalizedString(id));
                System.out.println("\n ============================== ");
            }
            ap.resetXPath();

//                System.out.println("Element name ==> " + vn2.toString(result) + " | " + vn2.getText());
//
            System.out.println("---++-------------------------------------------------------------------------------------------++------");

            System.out.println("--------------------------------------");
            System.out.println("Count : " + count);
            System.out.println("Count2 : " + count2);
            System.out.println("--------------------------------------");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EntityException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XPathParseException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XPathEvalException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NavException ex) {
            Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fis2.close();
            } catch (IOException ex) {
                Logger.getLogger(Test4VTD2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
