/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import com.google.common.collect.Lists;
import it.cnr.irea.ediT.model.EndPointType;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author Luca Frigerio
 */
public class TestListQuery {
    
    public TestListQuery() {
    }
//    @Test
    public void test() throws Exception {
        
        
        List<EndPointType> endpoint = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            EndPointType e = new EndPointType(UUID.randomUUID().toString());
            e.setMethod(UUID.randomUUID().toString());
            e.setSparqlEndpoint(UUID.randomUUID().toString());
            e.setQueryParameter(UUID.randomUUID().toString());
            endpoint.add(e);
        }
        
        String value = endpoint.get(3).getQueryParameter();
        String falsevalue = "falso";
        
        Optional<EndPointType> end = endpoint.stream()
                .filter(t -> t.getQueryParameter().equals(value))
                .findAny();
        
        
        System.out.println("**** > " +  end.get().getId());
        
        Optional<EndPointType> end2 = endpoint.stream()
                .filter(t -> t.getQueryParameter().equals(falsevalue))
                .findAny();
        
        if (end2.isPresent()) {
            System.out.println("**** > " +  end2.get().getId());
            Assert.assertTrue("TROVATO MA E FALSO", false);
        } else {
            Assert.assertTrue("ok", true);
        }
        
                
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
