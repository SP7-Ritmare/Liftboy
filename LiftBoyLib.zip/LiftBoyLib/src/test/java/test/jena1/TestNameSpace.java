/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Luca Frigerio
 */
public class TestNameSpace {

    public TestNameSpace() {
    }

    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/3/";
    private String PATH2 = "/home/carnauser/Scrivania/cristianoRDFExample/2/";
    private String FILENAME1 = "RNDT_dataset_v5.00.xml";
    private String FILENAME2 = "generated_11576.xml";

//    @Test
    public void test() throws FileNotFoundException {
        try {
            File file = new File(PATH + FILENAME1);
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            XMLStreamReader reader = inputFactory.createXMLStreamReader(new FileInputStream(file));
            Set<String> namespaces = new HashSet<>();
            while (reader.hasNext()) {
                int evt = reader.next();
                if (evt == XMLStreamConstants.START_ELEMENT) {
                    QName qName = reader.getName();
                    int counter = reader.getAttributeCount();
                    for( int i = 0; i < counter; i++) {
                        String x = reader.getAttributePrefix(i);
                        if(x!=null) {
                            namespaces.add(x);
                        }
                    }
                    
                    
//                    if (qName != null) {
//                        if (qName.getPrefix() != null && qName.getPrefix().compareTo("") != 0) {
//                            namespaces.add(qName.);
//                        }
//                    }
                }
            }

            for (String namespace : namespaces) {
                System.out.println(namespace);
            }
        } catch (XMLStreamException ex) {
            Logger.getLogger(TestNameSpace.class.getName()).log(Level.SEVERE, null, ex);
            assertTrue(false);
        }
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
