/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import cnr.lf.lflog.Loggator;
import cnr.lf.template.assembler.TemplateElementAssembler;
import cnr.lf.template.classes.Preamble;
import cnr.lf.xmlAssembler.BasicXsl;
import cnr.lf.xmlAssembler.QueryExecutor;
import cnr.lf.xmlAssembler.VTDUtil;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import com.google.common.collect.Lists;
import com.lf.cnr.util.DateUtil;
import com.lf.cnr.util.Logs;
import com.lf.cnr.util.Util;
import it.cnr.irea.ediT.model.CodeList;
import it.cnr.irea.ediT.model.PreTemplateElement;
import it.cnr.irea.ediT.model.PreTemplateItem;
import it.cnr.irea.ediT.model.TempRoot;
import it.cnr.irea.ediT.model.TemplateElement;
import it.cnr.irea.ediT.model.TemplateElementList;
import it.cnr.irea.ediT.model.TemplateItem;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author Luca Frigerio
 */
public class TestVTDUtil {

    public TestVTDUtil() {

    }

    
    private final AtomicReference<String> xml_path = new AtomicReference<>();
    private final AtomicReference<Preamble> version = new AtomicReference<>();
    private String TAX = "TestVTDUtil";
    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/12/";
//    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/6/";
    private String PATH2 = "/home/carnauser/Scrivania/cristianoRDFExample/5/";
    private String PATH3 = "/home/carnauser/Scrivania/cristianoRDFExample/Generated/";
    private String FOGLIO_DI_STYLE = "/home/carnauser/Scrivania/cristianoRDFExample/FoglioStile/identity_plus_comment.xsl";
//    private String FILENAME2 = "0.xml";
    private String FILENAME2 = "18.xml";
//    private String FILENAME2 = "36.xml";
//    private String FILENAME1 = "isoFromThredds_v1.00.xml";
    private String FILENAME1 = "iso2ediml_v3.00.xml";
//    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/3/";
//    private String PATH2 = "/home/carnauser/Scrivania/cristianoRDFExample/2/";
//    private String PATH3 = "/home/carnauser/Scrivania/cristianoRDFExample/Generated/";
//    private String FILENAME1 = "RNDT_dataset_v5.00.xml";
//    private String FILENAME2 = "generated_11576.xml";

    @Test
    public void test() {

        Loggator log = Loggator.getInstance();
        log.init("", true, true, true, true, true, true);

        List<PreTemplateElement> exit = null;

        try {
            VTDUtil vtdutil = new VTDUtil(PATH + FILENAME1, PATH + FILENAME2, xml_path,version);
            
            

            exit = vtdutil.getElemetsEdml();
        } catch (Exception ex) {

            Logger.getLogger(TestVTDUtil.class.getName()).log(Level.SEVERE, null, ex);
            assertTrue(false);
        }

//        if (exit == null) {
//            assertTrue("EXIT E' NULLO", false);
//        } else {
//            for (PreTemplateElement e : exit) {
//                Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
//                for (TemplateItem p : e.getItems()) {
//                    PreTemplateItem pe = (PreTemplateItem) p;
//                    if (pe.isToSearch()) {
//
//                    }
//                }
//                Logs.domain(TAX, e.toString());
//
//            }
//        }
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "NOW WE CAN START TO DO QUERIES");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "VERSION" + version.get());
        
//        String versionI = "<version>";
//        String versionF = "</version>";
//        String versionout = "";
//        int posI = version.get().indexOf(versionI) + versionI.length();
//        int posF =version.get().indexOf(versionF);
//        
//        Logs.domain(TAX, "VERSION -> " + version.get().substring(posI, posF));
//        
//        String templateI = "<template>";
//        String templateF = "</template>";
//        
//        posI = version.get().indexOf(templateI) + templateI.length();
//        posF =version.get().indexOf(templateF);
//        
//        Logs.domain(TAX, "TEMPLATE -> " + version.get().substring(posI, posF));
//        String fileIDI = "<fileId>";
//        String fileIDF = "</fileId>";
//        
//        posI = version.get().indexOf(fileIDI) + fileIDI.length();
//        posF =version.get().indexOf(fileIDF);
//        
//        Logs.domain(TAX, "FILEID -> " + version.get().substring(posI, posF));
//        String fileUriI = "<fileUri>";
//        String fileUriF = "</fileUri>";
//        
//        posI = version.get().indexOf(fileUriI) + fileUriI.length();
//        posF =version.get().indexOf(fileUriF);
//        
//        Logs.domain(TAX, "FILEURI -> " + version.get().substring(posI, posF));
        
        
        
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "NOW WE CAN START TO DO QUERIES");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");

        for (PreTemplateElement e : exit) {
            QueryExecutor qe = new QueryExecutor(e);
            try {
                qe.doSearch();
 
            } catch (IOException ex) {
                Logger.getLogger(TestVTDUtil.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, " X_PATH : " + xml_path.get());
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-----FACCIO UN PO' LA SOMMA---------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        for (PreTemplateElement pe : exit) {
            for (Object pio : pe.getItems()) {
                PreTemplateItem pi = (PreTemplateItem) pio;
                if (pi.getValue() != null) {
                    for (String value : pi.getMultiple_values()) {
                        Logs.domain(TAX, pi.getId() + " : " + value);
                    }
                    Logs.domain(TAX, "Is To Search : " + pi.isToSearch());
                    
                    if (pi.getMultiple_codevalue() != null) {
                        Logs.domain(TAX, "Value Size : " + pi.getMultiple_values().size());
                    }
                   
                    Logs.domain(TAX, "Is Multiple : " + pe.isIsMultiple());
                    Logs.domain(TAX, "Is CodeList : " + pi.isCodelist());
                    if (pi.getMultiple_codevalue() != null) {
                        Logs.domain(TAX, "Codevalue Size : " + pi.getMultiple_codevalue().size());
                        for ( String key: pi.getMultiple_codevalue().keySet()) {
                            Logs.domain(TAX, "KEY : " + key );
                            int i = 0;
                            for (String keyz : pi.getMultiple_codevalue().get(key) ) {
                                Logs.domain(TAX, "Value ("+i+"): " + keyz );
                                i++;
                            }
                             
                            Logs.domain(TAX, "------------------");
                        }
                    }
                    if (pi.getMultiple_to_search() != null) {
                        Logs.domain(TAX, "To_Search Size : " + pi.getMultiple_to_search().size());
                    }
                    Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
                }

            }
        }
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        JaxbAnnotationModule jaxbAnnotationModule = new JaxbAnnotationModule();
        List<TemplateElement> elements = Lists.newArrayList();

        for (PreTemplateElement pe : exit) {
            try {
                elements.addAll(TemplateElementAssembler.fromPreTemplateElementToTemplateElement(pe));
            } catch (Exception ex) {
                Logger.getLogger(TestVTDUtil.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        JacksonXmlModule module = new JacksonXmlModule();
        module.setDefaultUseWrapper(false);
        TemplateElementList elist = new TemplateElementList();
        elist.setVersion(version.get().getVersion());
        elist.setTemplateName(version.get().getTemplate());
        elist.setFileId(version.get().getFileId());
        elist.setFileId(version.get().getFileUri());
        elist.setElements(elements);
        XmlMapper xmlMapper = new XmlMapper(module);
        xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);

        String filename = PATH3 + DateUtil.convertToString(new Date(), DateUtil.ANNOMESEGIORNOORAMINUTISECONDO) + ".xml";
        String filename_xlst = PATH3 + DateUtil.convertToString(new Date(), DateUtil.ANNOMESEGIORNOORAMINUTISECONDO) + "_TRANSFORMED.xml";
        try {
            xmlMapper.writeValue(new File(filename), new TempRoot(version.get().getVersion(),version.get().getTemplate(),version.get().getFileId(),version.get().getFileUri(),elements));
        } catch (IOException ex) {
            Logger.getLogger(TestVTDUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!Util.isNullOrEmpty(xml_path.get())) {
            BasicXsl.xsl(filename, filename_xlst, xml_path.get());
            Logs.domain(TAX, "--APPLICATA LA TRASFORMAZIONE");
        } else {
            Logs.domain(TAX, "--NESSUN FOGLIO DI STILE");
        }
        
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");
        Logs.domain(TAX, CodeList.CODELISTQUERY);
        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
