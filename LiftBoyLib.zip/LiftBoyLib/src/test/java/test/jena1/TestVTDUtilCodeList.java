/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.jena1;

import cnr.lf.template.classes.Preamble;
import cnr.lf.xmlAssembler.VTDUtil;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Luca Frigerio
 */
public class TestVTDUtilCodeList {
private final AtomicReference<String> xml_path = new AtomicReference<>();
private final AtomicReference<Preamble> version = new AtomicReference<>();
    public TestVTDUtilCodeList() {

    }

    private String PATH = "/home/carnauser/Scrivania/cristianoRDFExample/3/";
    private String PATH2 = "/home/carnauser/Scrivania/cristianoRDFExample/2/";
    private String FILENAME1 = "RNDT_dataset_v5.00.xml";
    private String FILENAME2 = "generated_11576.xml";

//    @Test
    public void test() {
        try {
            VTDUtil vtdutil = new VTDUtil(PATH + FILENAME1,PATH2 + FILENAME2,xml_path ,version);
            
//            vtdutil.getCodeList();
        } catch (Exception ex) {
            
            
            Logger.getLogger(TestVTDUtilCodeList.class.getName()).log(Level.SEVERE, null, ex);
            assertTrue(false);
        }
        
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
