package cnr.lf.lifting.liftingui;

import cnr.lf.lflog.Loggator;
import cnr.lf.template.assembler.TemplateElementAssembler;
import cnr.lf.template.classes.Preamble;
import cnr.lf.xmlAssembler.BasicXsl;
import cnr.lf.xmlAssembler.QueryExecutor;
import cnr.lf.xmlAssembler.VTDUtil;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.common.collect.Lists;
import com.lf.cnr.util.DateUtil;
import com.lf.cnr.util.Logs;
import com.lf.cnr.util.Util;
import it.cnr.irea.ediT.model.PreTemplateElement;
import it.cnr.irea.ediT.model.TempRoot;
import it.cnr.irea.ediT.model.TemplateElement;
import it.cnr.irea.ediT.model.TemplateElementList;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
/**
 *
 * @author Luca Frigerio
 */
public class FXMLController implements Initializable {

    private final AtomicReference<String> xml_path = new AtomicReference<>();
    private final AtomicReference<Preamble> version = new AtomicReference<>();
    private String TAX = "TestVTDUtil";
    @FXML
    private Label label;
    @FXML
    private Button button;

    @FXML
    private TextField template_path;
    @FXML
    private TextField error;
    @FXML
    private TextField iso_path;

    @FXML
    private TextField destination_path;

    @FXML
    private ImageView image;

    private boolean isrunning = false;

    private String TEMPLATE_PATH;
    private String ISO_PATH;
    private String XML_DESTINATION_PATH;
    private String errortxt = "";
    private String logs_path;

    private Thread thread;

    public String getPath() {
        URL rootPath = getClass().getResource("");
        String URI = rootPath.toString().substring(9);
        String[] currentPath = URI.split("LiftingUI-1.0-SNAPSHOT.jar!");
        currentPath[0] = currentPath[0].replaceAll("%20", " ");
        return currentPath[0];
    }

    @FXML
    private void handleTemplateChoser(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();

        fileChooser.setInitialDirectory(new File(getPath()));
        fileChooser.setTitle("Template File");
        File file = fileChooser.showOpenDialog(new Stage());
        System.out.println(file);
        template_path.setText(file.getAbsolutePath());
    }

    @FXML
    private void handlerOutputDir(ActionEvent event) {

        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setInitialDirectory(new File(getPath()));
        chooser.setTitle("OutPut Folder ");
        File selectedDirectory = chooser.showDialog(new Stage());
        destination_path.setText(selectedDirectory.getAbsolutePath() + "/");
        logs_path = selectedDirectory.getAbsolutePath() + "/";

    }

    @FXML
    private void handleIsoChoser(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(getPath()));
        fileChooser.setTitle("Iso File");
        File file = fileChooser.showOpenDialog(new Stage());
        System.out.println(file);
        iso_path.setText(file.getAbsolutePath());
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if (!isrunning) {

            button.setText("Stop");

            Loggator log = Loggator.getInstance();
            log.init(logs_path, true, true, true, true, true, false);
            errortxt = "";
            isrunning = true;
            TEMPLATE_PATH = template_path.getText();
            ISO_PATH = iso_path.getText();
            XML_DESTINATION_PATH = destination_path.getText();

            thread = new Thread(new Runnable() {
                @Override
                public void run() {

                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            image.setVisible(true);
//                            error.setVisible(false);

                            label.setText("Running... ");
                        }
                    });

                    boolean ok = true;

                    File f = new File(TEMPLATE_PATH);
                    if (!f.exists()) {
                        errortxt = errortxt + "Template File " + TEMPLATE_PATH + " does not exist\n";
                        ok = false;
                    }
                    f = new File(ISO_PATH);
                    if (!f.exists()) {
                        errortxt = errortxt + "Iso File " + ISO_PATH + " does not exist\n";
                        ok = false;
                    }
                    f = new File(XML_DESTINATION_PATH);
                    if (!f.exists()) {
                        errortxt = errortxt + "Destination Dir " + XML_DESTINATION_PATH + " does not exist\n";
                        ok = false;

                    }

//                    else {
//                        if (!f.isDirectory()) {
//                            errortxt = errortxt + "Destination Dir " + XML_DESTINATION_PATH + " is not a valid path\n";
//                            ok = false;
//                        }
//                    }
                    if (ok) {

                        List<PreTemplateElement> exit = null;

                        try {
                            VTDUtil vtdutil = new VTDUtil(TEMPLATE_PATH, ISO_PATH, xml_path, version);

                            exit = vtdutil.getElemetsEdml();
                        } catch (final Exception ex) {

                            errortxt = errortxt + ex.getMessage().toString() + "\n";
                            isrunning = false;

                            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);

                        }


                        Logs.domain(TAX, "-------------------------------------------------------------------------------------------------------");

                        for (PreTemplateElement e : exit) {
                            QueryExecutor qe = new QueryExecutor(e);
                            try {
                                qe.doSearch();

                            } catch (final IOException ex) {

                                errortxt = errortxt + ex.getMessage().toString() + "\n";
                                isrunning = false;

                                Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
                            }

                        }

                        List<TemplateElement> elements = Lists.newArrayList();
                        for (PreTemplateElement pe : exit) {
                            try {
                                elements.addAll(TemplateElementAssembler.fromPreTemplateElementToTemplateElement(pe));
                            } catch (final Exception ex) {
                                errortxt = errortxt + ex.getMessage().toString() + "\n";
                                isrunning = false;

                                Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        JacksonXmlModule module = new JacksonXmlModule();
                        module.setDefaultUseWrapper(false);
                        TemplateElementList elist = new TemplateElementList();
                        elist.setElements(elements);
                        elist.setVersion(version.get().getVersion());
                        elist.setTemplateName(version.get().getTemplate());
                        elist.setFileId(version.get().getFileId());
                        elist.setFileId(version.get().getFileUri());
                        XmlMapper xmlMapper = new XmlMapper(module);
                        xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);

                        String data = DateUtil.convertToString(new Date(), DateUtil.ANNOMESEGIORNOORAMINUTISECONDO);

                        String filename = XML_DESTINATION_PATH + data + ".xml";
                        String filename_transformed = XML_DESTINATION_PATH + data + "_TRANSFORMED.xml";

                        try {
                              xmlMapper.writeValue(new File(filename), new TempRoot(version.get().getVersion(),version.get().getTemplate(),version.get().getFileId(),version.get().getFileUri(),elements));
                        } catch (final IOException ex) {
                            errortxt = errortxt + ex.getMessage().toString() + "\n";
                            isrunning = false;

                            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
                        }

//                        if (! Util.isNullOrEmpty(xsltfile.getText())) {
//                            BasicXsl.xsl(filename, filename_transformed, xsltfile.getText());
//                        }
                        if (!Util.isNullOrEmpty(xml_path.get())) {

                            File fX = new File(xml_path.get());
                            if (!fX.exists()) {

                                Logs.domain(TAX, "--XML STYLE SHEET FILE DOES NOT EXIST : CHECK IF THE PATH IS CORRECT");
                            } else {
                                BasicXsl.xsl(filename, filename_transformed, xml_path.get());
                                Logs.domain(TAX, "--XML STYLE SHEET APPLIED");
                            }

                        } else {
                            Logs.domain(TAX, "--XML STYLE SHEET DOES NOT EXIST");
                        }

                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {

                                image.setVisible(false);
                                label.setText("Done!");

//                                error.setVisible(true);
                                error.setText(errortxt);

                            }
                        });

                    }

                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            image.setVisible(false);
                            button.setText("Run!");

//                            label.setText(errortxt);
                        }
                    });

                    isrunning = false;

                }
            });
            thread.start();

        } else {

//            label.setText("Don't click 2 times...");
            thread.interrupt();

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    image.setVisible(false);

                    button.setText("Run!");

                    image.setVisible(false);
//                     error.setVisible(true);
                    error.setText("Thread Stopped By User!");
//                            label.setText(errortxt);

                }
            });

            isrunning = false;

//            label.setText("Error");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
    }
}
